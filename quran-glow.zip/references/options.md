# الخيارات

## الأوامر الأساسية
`S` = مجلد `scripts` في البلقن.
```
python3 $S/run_all.py <ملف أو مجلد> --out OUT [خيارات]
```

| الخيار | القيم |
|---|---|
| `--riwayah` | `hafs` حفص (الافتراضي) · `shouba` شعبة · `warsh` ورش · `qaloon` قالون · `doori` الدوري · `soosi` السوسي · `bazzi` البزي · `qumbul` قنبل |
| `--tafsir` | `muyassar` الميسر (الافتراضي) · `mukhtasar` المختصر (أقصر، ممتاز للريلز) · `saadi` السعدي (طويل، بس للآيات القصيرة) · `en` · `id` · `tr` · `fr` · `ru` · `fa` · `none` |
| `--theme` | `navy_gold` كحلي وذهبي · `royal_blue` أزرق ملكي · `emerald` زمردي · `ramadan` رمضاني · `turquoise` فيروزي · `burgundy` عنابي · `silver_night` فضي ليلي · `white_soft` أبيض هادئ · `rose` وردي ناعم · `sand` رملي · `mono` أبيض وأسود · `mushaf` مصحف ورقي |
| `--modes` | أي مجموعة من `reel,square,youtube,original` مفصولة بفواصل (الافتراضي `reel,square`) |
| `--bg` | للصوت فقط: `pattern` زخرفة · `stars` نجوم · `bokeh` أضواء · `gradient` تدرج · `arch` قوس |
| `--handle` `--reciter` | اسم الحساب يطلع أعلى الفيديو وفي الغلاف، واسم القارئ يطلع في الغلاف والمنشور |
| `--model` | `auto` (الافتراضي: يبدأ بـ small ويعيد بـ turbo إذا ضعف التطابق) · `small` · `turbo` (الأدق، حوالي 1GB) · `base` |
| `--range 27:59-62` | بدون تعرّف على الصوت: سورة:آيات. التوقيت تقريبي |
| `--plan-only` | يطلّع الخطة والتوقيت ويفحصها بدون تصيير |
| `--preview [ثواني]` | معاينة سريعة (4–8 ثواني) للمقاس الأول، بجودة منخفضة |
| `--replan` | يعيد بناء الخطة من الصفر |
| `--fast` | تصيير سريع للتجارب فقط |
| `--no-credit` | بدون سطر المصادر في نص المنشور |
| `--no-verify` | يتخطى الفحص الآلي (لا تستخدمه للتسليم) |

على خطة موجودة، `--theme` و`--tafsir` و`--handle` و`--reciter` تحدّث `plan.json` وتعيد التصيير بدون إعادة التفريغ الصوتي.

## الإعدادات المحفوظة (مرة وحدة تكفي)
```
python3 $S/config.py show
python3 $S/config.py set handle @name reciter "اسم القارئ" theme navy_gold riwayah hafs tafsir muyassar modes reel,square
python3 $S/config.py set credit off          # بدون سطر المصادر
python3 $S/config.py colors '{...}'          # ألوان هوية خاصة (أسفل)
python3 $S/config.py reset
```
تنحفظ في `~/quran-work/config.json` وتبقى بعد تحديث البلقن، وأي خيار تكتبه في الأمر يتغلّب عليها.

## ألوان خاصة غير الثيمات (مثلاً ألوان الهوية)
حوّل أسماء الألوان اللي يقولها المستخدم إلى hex بنفسك:
```
python3 $S/config.py colors '{"ayah":"#FFFFFF","glow":"#C9A227","accent":"#C9A227","tafsir":"#FFFFFF","shade":"#0A1A2F","bg":["#0A1A2F","#16324F","#C9A227"],"glow_strength":1.0}'
```
- تنطبق على كل خطة جديدة. وإذا الخطة موجودة، حط نفس القيمة في `plan.json` تحت المفتاح `"colors"`.
- `glow_strength` من 0 (بدون توهج) لين 1.5.
- إذا ما حدد المستخدم ألوان ولا فيه ثيم محفوظ: `python3 $S/preview_themes.py OUT/themes.jpg` وأرسلها له يختار. وإذا ما رد، استخدم `navy_gold`.

## أحجام الخط
في `plan.json`: `"style": {"fs": 64, "tfs": 25}` (للصوت فقط الافتراضي 80 و29).
إذا النص الطويل ما ساع، الرندر يصغّر الخط تلقائياً (إلى 40 للآية و17 للتفسير) ويطبع ملاحظة بذلك.
