# Build plan.json automatically from matches + pauses (phrases follow the reciter's breaths).
# usage: python3 auto_plan.py matches.json pauses.json plan.json [--theme ..] [--tafsir ..] [--handle ..] [--reciter ..]
#        python3 auto_plan.py --range 27:59-62 pauses.json plan.json   (no speech recognition: approximate timing)
import argparse, json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import load_riwayah, tokens, WAQF

MIN_PHRASE = 3.0  # seconds; shorter phrases are merged into a neighbour


def ayah_lengths(r, s):
    return {x['ayah']: len(tokens(x['text'])) for x in load_riwayah(r) if x['surah'] == s}


def from_matches(M, P, dur):
    r, S = M['riwayah'], M['surah']
    LEN = ayah_lengths(r, S)
    segs = []  # (ayah, wf, wt, start, end)
    for c in M['chunks']:
        loc = c.get('loc')
        if not loc or loc['from'][0] != S or loc['to'][0] != S:
            continue
        (_, a1, w1), (_, a2, w2) = loc['from'], loc['to']
        if a1 == a2:
            segs.append([a1, w1, w2, c['start'], c['end']]); continue
        parts = [(a1, w1, LEN[a1])] + [(a, 1, LEN[a]) for a in range(a1 + 1, a2)] + [(a2, 1, w2)]
        tot = sum(t - f + 1 for _, f, t in parts); t0 = c['start']
        for a, f, t in parts:
            d = (c['end'] - c['start']) * (t - f + 1) / tot
            segs.append([a, f, t, t0, t0 + d]); t0 += d
    ph = []  # phrases: dict(ayah, wf, wt, s, e)
    for a, f, t, s, e in segs:
        cur = ph[-1] if ph else None
        if cur and a == cur['ayah'] and f <= cur['wt'] and t > cur['wt'] and cur['wt'] - f < 2 and f > cur['wf']:
            cur['wt'] = f - 1                                  # 1-2 word overlap: reciter breathed and restarted the word
            ph.append({'ayah': a, 'wf': f, 'wt': t, 's': s, 'e': e})
        elif cur and a == cur['ayah'] and f <= cur['wt']:    # reciter repeated words: same phrase continues
            cur['wt'] = max(cur['wt'], t); cur['e'] = e
        elif cur and a < cur['ayah']:                          # went back to an earlier ayah: keep showing current
            cur['e'] = e
        else:
            if cur and a > cur['ayah']:
                cur['wt'] = LEN[cur['ayah']]                    # previous ayah was completed
                f = 1
            elif cur:
                f = cur['wt'] + 1
            elif f <= 3:
                f = 1
            ph.append({'ayah': a, 'wf': f, 'wt': max(f, t), 's': s, 'e': e})
    if not ph:
        raise SystemExit('no recited ayat were recognised — check matches.json')
    if ph[-1]['wt'] >= LEN[ph[-1]['ayah']] - 2:
        ph[-1]['wt'] = LEN[ph[-1]['ayah']]
    # merge too-short phrases inside the same ayah
    i = 0
    while i < len(ph):
        p = ph[i]
        if p['e'] - p['s'] < MIN_PHRASE and len(ph) > 1:
            j = i - 1 if i > 0 and ph[i - 1]['ayah'] == p['ayah'] else (i + 1 if i + 1 < len(ph) and ph[i + 1]['ayah'] == p['ayah'] else None)
            if j is not None:
                q = ph[j]
                q['wf'], q['wt'] = min(q['wf'], p['wf']), max(q['wt'], p['wt'])
                q['s'], q['e'] = min(q['s'], p['s']), max(q['e'], p['e'])
                ph.pop(i); i = max(0, i - 1); continue
        i += 1
    # display times: switch at the middle of the breath pause before each phrase
    pauses = P['pauses']
    def mid_before(t):
        c = [((a + b) / 2) for a, b in pauses if b <= t + 0.05 and t - b < 1.5]
        return max(c) if c else t
    for k, p in enumerate(ph):
        p['ds'] = 0.0 if k == 0 and p['s'] < 3 else (max(0.0, p['s'] - 0.3) if k == 0 else mid_before(p['s']))
    for k, p in enumerate(ph):
        if k + 1 < len(ph):
            p['de'] = ph[k + 1]['ds']
        else:  # last phrase: hold until the next long silence (>= 2 s) or the end of the file
            long_gap = [a for a, b in pauses if a >= p['e'] - 0.1 and b - a >= 2.0]
            p['de'] = min(long_gap) + 0.5 if long_gap else dur
    return r, S, ph


def from_range(rng, P, dur, r):
    s, ay = rng.split(':'); a1, a2 = (int(x) for x in (ay.split('-') + [ay])[:2])
    S = int(s)
    AY = {x['ayah']: tokens(x['text']) for x in load_riwayah(r) if x['surah'] == S}
    units = []  # (ayah, wf, wt) split at waqf signs
    for a in range(a1, a2 + 1):
        toks, f = AY[a], 1
        for k, t in enumerate(toks, 1):
            if any(ch in WAQF for ch in t) or k == len(toks):
                units.append((a, f, k)); f = k + 1
    speech, t = [], 0.0
    for a, b in P['pauses']:
        if a - t > 0.6:
            speech.append((t, a))
        t = b
    if dur - t > 0.6:
        speech.append((t, dur))
    W = sum(u[2] - u[1] + 1 for u in units); T = sum(b - a for a, b in speech); ph = []
    acc = 0
    for u in units:  # place each unit where its share of words falls in the speech time
        w = u[2] - u[1] + 1; mid = (acc + w / 2) / W * T; acc += w; tt = 0
        for a, b in speech:
            if tt + (b - a) >= mid:
                ci = (a, b); break
            tt += b - a
        if ph and ph[-1]['chunk'] == ci and ph[-1]['ayah'] == u[0]:
            ph[-1]['wt'] = u[2]
        else:
            ph.append({'ayah': u[0], 'wf': u[1], 'wt': u[2], 's': ci[0], 'e': ci[1], 'chunk': ci})
    for k, p in enumerate(ph):
        p['ds'] = 0.0 if k == 0 else (ph[k - 1]['e'] + p['s']) / 2 if p['s'] > ph[k - 1]['e'] else p['s']
    for k, p in enumerate(ph):
        p['de'] = ph[k + 1]['ds'] if k + 1 < len(ph) else dur
    return r, S, ph


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('matches', nargs='?'); ap.add_argument('pauses'); ap.add_argument('out')
    ap.add_argument('--range'); ap.add_argument('--riwayah', default='hafs')
    for k in ('theme', 'tafsir', 'handle', 'reciter'):
        ap.add_argument('--' + k)
    a = ap.parse_args()
    P = json.load(open(a.pauses)); dur = P['duration']
    if a.range:
        r, S, ph = from_range(a.range, P, dur, a.riwayah)
    else:
        r, S, ph = from_matches(json.load(open(a.matches, encoding='utf-8')), P, dur)
    plan = {'riwayah': r, 'tafsir': a.tafsir or 'muyassar', 'theme': a.theme or 'navy_gold', 'surah': S,
            'approximate_timing': bool(a.range), 'ayat': []}
    if a.handle:
        plan['brand'] = {'handle': a.handle}
    if a.reciter:
        plan['reciter'] = a.reciter
    for p in ph:
        if not plan['ayat'] or plan['ayat'][-1]['ayah'] != p['ayah']:
            plan['ayat'].append({'ayah': p['ayah'], 'phrases': [], 'tafsir_split': 'auto'})
        plan['ayat'][-1]['phrases'].append([p['wf'], p['wt'], round(p['ds'], 2), round(p['de'], 2)])
    json.dump(plan, open(a.out, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    for A in plan['ayat']:
        print(S, A['ayah'], A['phrases'])


if __name__ == '__main__':
    main()
