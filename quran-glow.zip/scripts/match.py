# Locate each transcribed chunk in the chosen riwayah's mushaf text.
# usage: python3 match.py chunks.json matches.json [--riwayah hafs]
import argparse, json, os, sys, difflib
from collections import Counter, defaultdict
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import load_riwayah, tokens, norm

JUNK = ('شترك', 'ترجمه', 'شكر', 'ننسي', 'موسيقي')  # Whisper hallucinations on breaths (alefs already stripped)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('chunks'); ap.add_argument('out'); ap.add_argument('--riwayah', default='hafs')
    a = ap.parse_args()
    stream = []  # (surah, ayah, word_no, normalised word)
    for x in load_riwayah(a.riwayah):
        k = 0
        for t in tokens(x['text']):
            k += 1
            nw = norm(t)
            if nw:
                stream.append((x['surah'], x['ayah'], k, nw))
    idx = defaultdict(list)
    for p, x in enumerate(stream):
        idx[x[3]].append(p)

    def fuzzy(qs, lo, hi, n):
        best = (0, None)
        for s0 in range(max(0, lo), min(len(stream), hi)):
            for L in range(max(1, n - 2), n + 3):
                r = difflib.SequenceMatcher(None, qs, ' '.join(x[3] for x in stream[s0:s0 + L])).ratio()
                if r > best[0]:
                    best = (r, (s0, s0 + L - 1))
        return best

    C = json.load(open(a.chunks, encoding='utf-8')); res = []
    for c in C:  # pass 1: global search by word votes
        q = [t for t in norm(c['text']).split() if t]
        if len(q) < 2 or any(j in norm(c['text']).replace(' ', '') for j in JUNK):
            res.append(None); continue
        votes = Counter()
        for k, t in enumerate(q):
            if len(t) < 3:
                continue
            ps = idx.get(t, [])
            if len(ps) > 400:
                continue
            for p in ps:
                votes[p - k] += 1
        best = (0, None)
        for st, _ in votes.most_common(8):
            b = fuzzy(' '.join(q), st - 2, st + 3, len(q))
            if b[0] > best[0]:
                best = b
        res.append({'q': q, 'best': best})
    sur = Counter()
    for r in res:
        if r and r['best'][1]:
            sur[stream[r['best'][1][0]][0]] += len(r['q'])
    main_s = sur.most_common(1)[0][0] if sur else None
    anch = [i for i, r in enumerate(res) if r and r['best'][1] and r['best'][0] >= 0.85 and len(r['q']) >= 3
            and stream[r['best'][1][0]][0] == main_s]
    out = []
    for i, c in enumerate(C):  # pass 2: re-search the rest between neighbouring anchors
        r = res[i]
        if r is None:
            out.append({**c, 'loc': None}); print(f"{c['start']:>7}-{c['end']:<7} — skip   {c['text']}"); continue
        best = r['best']
        if i not in anch and anch:
            prv = [j for j in anch if j < i]; nxt = [j for j in anch if j > i]
            lo = res[prv[-1]]['best'][1][0] - 5 if prv else res[nxt[0]]['best'][1][0] - 80
            hi = res[nxt[0]]['best'][1][1] + 5 if nxt else res[prv[-1]]['best'][1][1] + 80
            b = fuzzy(' '.join(r['q']), lo, hi, len(r['q']))
            if b[1] and b[0] >= 0.5:
                best = b
        if best[1] is None or best[0] < 0.5:
            out.append({**c, 'loc': None}); print(f"{c['start']:>7}-{c['end']:<7} — no match   {c['text']}"); continue
        x0, x1 = stream[best[1][0]], stream[best[1][1]]
        loc = {'from': list(x0[:3]), 'to': list(x1[:3]), 'score': round(best[0], 2)}
        out.append({**c, 'loc': loc})
        print(f"{c['start']:>7}-{c['end']:<7} {x0[0]}:{x0[1]} w{x0[2]} → {x1[0]}:{x1[1]} w{x1[2]}  ({loc['score']})  {c['text']}")
    json.dump({'riwayah': a.riwayah, 'surah': main_s, 'chunks': out}, open(a.out, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)


if __name__ == '__main__':
    main()
