# Contact sheet of all colour themes (so the user can pick one). usage: python3 preview_themes.py out.jpg [riwayah]
import os, sys
from PIL import Image, ImageDraw
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import load_themes, resolve_theme, riwayah_files, font_path, load_riwayah, tokens
from render import Txt, render_block, separator
from background import make_still

r = sys.argv[2] if len(sys.argv) > 2 else 'hafs'
_, af, _ = riwayah_files(r)
ayah = next(x for x in load_riwayah(r) if (x['surah'], x['ayah']) == (1, 2 if r == 'hafs' else 1))
text = ' '.join(tokens(ayah['text']))
tf = font_path('IBMPlexSansArabic-Medium.ttf')
W, H = 540, 540
tiles = []
for key in load_themes():
    th = resolve_theme(key)
    im = make_still('pattern', th, W, H).convert('RGBA')
    A = Txt(af, 40, True, 'ar', lh=1.7); T = Txt(tf, 17, True, 'ar', lh=1.5); LB = Txt(tf, 13, True, 'ar', lh=1.4)
    blk, pad = render_block(A, A.wrap(text, 470), 470, th['ayah'], th['glow'], th.get('glow_strength', 1), shadow=(0 if th.get('panel') else .55), pad=60)
    if th.get('panel'):
        ImageDraw.Draw(im).rounded_rectangle([30, 170, W - 30, 400], 22, fill=tuple(int(th['shade'][i:i + 2], 16) for i in (1, 3, 5)) + (240,))
    im.alpha_composite(blk, ((W - blk.width) // 2, 190 - pad))
    im.alpha_composite(separator(300, LB, 'التفسير الميسر', th['accent']), (120, 300))
    name = Txt(tf, 24, True, 'ar', lh=1.4)
    nb, p2 = render_block(name, [th['name'] + '  ·  ' + key], 500, th['accent'], shadow=(0 if th.get('panel') else .8), pad=10)
    im.alpha_composite(nb, ((W - nb.width) // 2, 440 - p2))
    tiles.append(im.convert('RGB'))
cols = 4; rows = (len(tiles) + cols - 1) // cols
sheet = Image.new('RGB', (cols * (W + 10) - 10, rows * (H + 10) - 10), 'white')
for i, t in enumerate(tiles):
    sheet.paste(t, ((i % cols) * (W + 10), (i // cols) * (H + 10)))
sheet.save(sys.argv[1], quality=90)
print(sys.argv[1])
