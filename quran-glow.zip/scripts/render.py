# Caption renderer (Pillow + raqm/HarfBuzz) — no browser needed.
# Produces transparent PNG layers the size of the output canvas:
#   t_<group>.png  separator + tafsir (+ paper panel for the "mushaf" theme)
#   a_<phrase>.png the glowing ayah phrase, sitting above its tafsir
#   brand.png      optional account handle
import json, os, sys
from functools import lru_cache
from PIL import Image, ImageDraw, ImageFilter, ImageFont, features
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import hexrgb, font_path

if not features.check('raqm'):
    raise SystemExit('Pillow was built without raqm: Arabic shaping unavailable. Run: pip install -U --break-system-packages pillow')


@lru_cache(None)
def F(path, size, var=None):
    f = ImageFont.truetype(path, size, layout_engine=ImageFont.Layout.RAQM)
    if var:
        try:
            f.set_variation_by_name(var)
        except Exception:
            pass
    return f


class Txt:
    def __init__(self, path, size, rtl, lang, var=None, lh=1.6):
        self.f, self.rtl, self.lang, self.size = F(path, size, var), rtl, lang, size
        self.lh = round(size * lh)
        a, d = self.f.getmetrics()
        self.base = round((self.lh - (a + d)) / 2 + a)
        self._w = {}

    def width(self, s):
        if s not in self._w:
            self._w[s] = self.f.getlength(s, direction='rtl' if self.rtl else 'ltr', language=self.lang)
        return self._w[s]

    def wrap(self, text, maxw, max_lines=6):
        """Balanced line breaking: fewest lines that fit, then minimise the longest line."""
        words = text.split(' ')
        n = len(words)
        line = lambda i, j: ' '.join(words[i:j])
        for L in range(1, max_lines + 1):
            if L > n:
                break
            # dp[k][j] = minimal max-width covering words[:j] with k lines
            INF = float('inf')
            dp = [[INF] * (n + 1) for _ in range(L + 1)]
            cut = [[0] * (n + 1) for _ in range(L + 1)]
            dp[0][0] = 0
            for k in range(1, L + 1):
                for j in range(1, n + 1):
                    for i in range(k - 1, j):
                        if dp[k - 1][i] == INF:
                            continue
                        w = self.width(line(i, j))
                        if w > maxw and j - i > 1:
                            continue
                        c = max(dp[k - 1][i], w)
                        if c < dp[k][j]:
                            dp[k][j], cut[k][j] = c, i
            if dp[L][n] < INF:
                out, j = [], n
                for k in range(L, 0, -1):
                    i = cut[k][j]
                    out.append(line(i, j))
                    j = i
                return out[::-1]
        return [text]

    def draw(self, d, lines, cx, top, fill):
        for i, s in enumerate(lines):
            d.text((cx, top + i * self.lh + self.base), s, font=self.f, fill=fill, anchor='ms',
                   direction='rtl' if self.rtl else 'ltr', language=self.lang)


def glow_layer(size, mask, color, strength):
    """CSS-like multi-layer text-shadow glow from an alpha mask."""
    out = Image.new('RGBA', size, (0, 0, 0, 0))
    if strength <= 0:
        return out
    c = hexrgb(color)
    light = tuple(int(v + (255 - v) * 0.6) for v in c)
    for sigma, a, col in [(20, .40, c), (12, .60, c), (6.5, .80, c), (3, .95, c), (1, 1.0, light)]:
        m = mask.filter(ImageFilter.GaussianBlur(sigma)).point(lambda v, k=min(1.0, a * strength): int(v * k))
        layer = Image.new('RGBA', size, col + (0,))
        layer.putalpha(m)
        out = Image.alpha_composite(out, layer)
    return out


def shadow_layer(size, mask, sigma=1.6, alpha=.6, dy=2):
    m = Image.new('L', size, 0)
    m.paste(mask, (0, dy))
    m = m.filter(ImageFilter.GaussianBlur(sigma)).point(lambda v: int(v * alpha))
    layer = Image.new('RGBA', size, (0, 0, 0, 0))
    layer.putalpha(m)
    return layer


def render_block(txt, lines, width, color, glow=None, strength=0, shadow=.6, pad=70):
    h = len(lines) * txt.lh + 2 * pad
    w = width + 2 * pad
    mask = Image.new('L', (w, h), 0)
    txt.draw(ImageDraw.Draw(mask), lines, w / 2, pad, 255)
    img = glow_layer((w, h), mask, glow, strength) if glow and strength > 0 else Image.new('RGBA', (w, h), (0, 0, 0, 0))
    if shadow:
        img = Image.alpha_composite(img, shadow_layer((w, h), mask, alpha=shadow))
    core = Image.new('RGBA', (w, h), hexrgb(color) + (0,))
    core.putalpha(mask)
    return Image.alpha_composite(img, core), pad


def separator(width, label_txt, label, accent):
    h = label_txt.lh
    img = Image.new('RGBA', (width, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    lw = label_txt.width(label) if label else 0
    gap = 14
    seg = max(0, (width - lw - 2 * gap) / 2) if label else width / 2
    r, g, b = hexrgb(accent)
    y = h // 2
    for x in range(int(seg)):
        a = int(242 * x / max(1, seg))
        d.line([(x, y), (x, y + 1)], fill=(r, g, b, a))                       # left line fades in
        d.line([(width - 1 - x, y), (width - 1 - x, y + 1)], fill=(r, g, b, a))  # right line fades in
    if label:
        glow = Image.new('L', img.size, 0)
        label_txt.draw(ImageDraw.Draw(glow), [label], width / 2, 0, 255)
        g2 = Image.new('RGBA', img.size, (r, g, b, 0))
        g2.putalpha(glow.filter(ImageFilter.GaussianBlur(5)).point(lambda v: int(v * .6)))
        img = Image.alpha_composite(img, g2)
        label_txt.draw(ImageDraw.Draw(img), [label], width / 2, 0, (r, g, b, 255))
    return img


def _overflows(t, text, maxw, max_lines):
    """True if `text` cannot be wrapped into <= max_lines lines of width <= maxw (the wrapper then returns it unsplit = overflow)."""
    if t.width(text) > maxw * max_lines * 0.97:   # cheap pre-check before the DP wrapper
        return True
    lines = t.wrap(text, maxw, max_lines)
    return len(lines) > max_lines or any(t.width(x) > maxw + 2 for x in lines)


def fit_size(make, size, texts, maxw, max_lines, floor):
    """Largest font size <= size (down to floor) at which every text fits the box. Long tafsir/ayat shrink instead of overflowing."""
    s = size
    while True:
        t = make(s)
        if s <= floor or not any(_overflows(t, x, maxw, max_lines) for x in texts):
            if s < size:
                print(f'ℹ️  صغّرت الخط من {size} إلى {s} عشان النص الطويل يستوي بالإطار', flush=True)
            return t, s
        s -= 1


def render_layers(L, out, W, H, bot, center=False):
    """L = layout.json dict. bot = distance from canvas bottom to the bottom of the caption block."""
    os.makedirs(out, exist_ok=True)
    th, st = L['theme'], L.get('style', {})
    fs, tfs = st.get('fs', 64), st.get('tfs', 25)
    side = st.get('side', 64)
    box = min(W - 2 * side, st.get('box', 1300 if W > 1500 else 952))
    ayah_w = min(box, st.get('ayah_w', 1250 if W > 1500 else 900))
    rt = L['tafsir_dir'] == 'rtl'
    A, fs = fit_size(lambda z: Txt(L['ayah_font'], z, True, 'ar', lh=1.7), fs,
                     [p['text'] for g in L['groups'] for p in g['phrases']], ayah_w, 4, 40)
    T, tfs = fit_size(lambda z: Txt(L['tafsir_font'], z, rt, L['tafsir_lang'], var=L.get('tafsir_var'), lh=1.62), tfs,
                      [g['tafsir'] for g in L['groups'] if g['tafsir']], box - 20, 7, 17)
    LB = Txt(L['label_font'], 18, rt, L['tafsir_lang'], var=L.get('tafsir_var'), lh=1.4)
    panel = th.get('panel')
    tops = {}
    for g in L['groups']:
        has_t = bool(g['tafsir'])
        tl = T.wrap(g['tafsir'], box - 20, 7) if has_t else []
        sep_h = (4 + LB.lh + 12) if has_t else 0
        t_h = len(tl) * T.lh
        t_top = H - bot - t_h
        sep_top = t_top - sep_h
        layer = Image.new('RGBA', (W, H), (0, 0, 0, 0))
        # ayah blocks for this group (needed first for the panel size)
        blocks = []
        for p in g['phrases']:
            al = A.wrap(p['text'], ayah_w, 4)
            blocks.append((p, al))
        max_ah = max(len(al) for _, al in blocks) * A.lh if blocks else 0
        if panel:
            pw = box + 40
            px0, py0 = (W - pw) // 2, sep_top - max_ah - 26
            card = Image.new('RGBA', (W, H), (0, 0, 0, 0))
            ImageDraw.Draw(card).rounded_rectangle([px0, py0, px0 + pw, H - bot + 22], 28, fill=hexrgb(th['shade']) + (240,),
                                                   outline=hexrgb(th['accent']) + (200,), width=3)
            layer = Image.alpha_composite(layer, card)
        if has_t:
            sw = int(box * 0.58)
            layer.alpha_composite(separator(sw, LB, L['tafsir_label'], th['accent']), ((W - sw) // 2, sep_top + 4))
            tb, pad = render_block(T, tl, box, th['tafsir'], shadow=(0 if panel else .85))
            layer.alpha_composite(tb, ((W - tb.width) // 2, t_top - pad))
        layer.save(os.path.join(out, f"t_{g['id']}.png"))
        for p, al in blocks:
            a_h = len(al) * A.lh
            a_top = sep_top - a_h
            ab, pad = render_block(A, al, ayah_w, th['ayah'], th['glow'], th.get('glow_strength', 1.0),
                                   shadow=(0 if panel else .55), pad=90)
            lay = Image.new('RGBA', (W, H), (0, 0, 0, 0))
            lay.alpha_composite(ab, ((W - ab.width) // 2, a_top - pad))
            lay.save(os.path.join(out, f"a_{p['id']}.png"))
            tops[p['id']] = a_top
    return tops


def render_brand(L, out, W, H, y):
    b = L.get('brand') or {}
    if not b.get('handle'):
        return None
    h = b['handle']
    rtl = sum(1 for ch in h if 0x600 <= ord(ch) <= 0x6FF) > len(h) / 3
    t = Txt(L['label_font_ar'], 26, rtl, 'ar' if rtl else 'en', lh=1.4)
    img = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    blk, pad = render_block(t, [b['handle']], int(t.width(b['handle'])) + 10, L['theme']['accent'], shadow=.7, pad=20)
    img.alpha_composite(blk, ((W - blk.width) // 2, int(y) - pad))
    p = os.path.join(out, 'brand.png')
    img.save(p)
    return p


if __name__ == '__main__':  # node-free CLI: python3 render.py layout.json outdir W H bottom
    L = json.load(open(sys.argv[1], encoding='utf-8'))
    print(render_layers(L, sys.argv[2], int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5])))
