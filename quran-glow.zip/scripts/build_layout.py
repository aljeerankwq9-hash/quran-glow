# plan.json -> layout.json (texts, fonts, colours) + timeline.json (times).
# Ayah text is ALWAYS sliced from the KFGQPC mushaf data by word numbers — never typed by hand.
# usage: python3 build_layout.py plan.json outdir
import json, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import (RIWAYAT, TAFSIR, riwayah_files, load_riwayah, tokens, load_tafsir, resolve_theme,
                    map_to_hafs, font_path)

SENT = re.compile(r'[.؟?!؛;]')


def split_tafsir(text, k):
    """Split into k consecutive parts at sentence ends (or commas) nearest to equal lengths. Text is not altered."""
    if k <= 1:
        return [text]
    ends = [m.end() for m in SENT.finditer(text) if m.end() < len(text) - 5]
    if len(ends) < k - 1:
        ends = sorted(set(ends + [m.end() for m in re.finditer('[،,]', text) if m.end() < len(text) - 5]))
    if len(ends) < k - 1:
        return [text]
    cuts, used = [], set()
    for q in range(1, k):
        target = len(text) * q / k
        c = min((e for e in ends if e not in used and (not cuts or e > cuts[-1])), key=lambda e: abs(e - target), default=None)
        if c is None:
            return [text]
        cuts.append(c); used.add(c)
    parts, prev = [], 0
    for c in cuts + [len(text)]:
        parts.append(text[prev:c].strip()); prev = c
    return [p.rstrip('،,').strip() if i < len(parts) - 1 else p for i, p in enumerate(parts)]


def main(pj, O):
    os.makedirs(O, exist_ok=True)
    plan = json.load(open(pj, encoding='utf-8'))
    r = plan.get('riwayah', 'hafs'); tk = plan.get('tafsir', 'muyassar'); S = plan['surah']
    _, ayah_font, r_label = riwayah_files(r)
    AY = {x['ayah']: x for x in load_riwayah(r) if x['surah'] == S}
    slug, t_label, lang, tdir = TAFSIR[tk]
    TF = load_tafsir(tk, S)
    hmap = map_to_hafs(r, S, [A['ayah'] for A in plan['ayat']])
    groups, timeline, review = [], [], []
    for A in plan['ayat']:
        ay = A['ayah']; toks = tokens(AY[ay]['text'])
        phrases = []
        for f, t, s, e in A['phrases']:
            assert 1 <= f <= t <= len(toks), f'{S}:{ay} words {f}-{t} outside 1-{len(toks)}'
            phrases.append({'w': (f, t), 'text': ' '.join(toks[f - 1:t]), 's': s, 'e': e})
        hafs_ayat = hmap.get(ay) or [ay]
        tafsir = ' '.join(TF.get(h, '') for h in hafs_ayat).strip() if slug else ''
        sp = A.get('tafsir_split', 'auto')
        if not tafsir:
            parts, tg = [''], [list(range(len(phrases)))]
        elif sp and sp != 'auto':
            i = tafsir.index(sp) + len(sp)
            parts = [tafsir[:i].strip().rstrip('،,').strip(), tafsir[i:].strip()]
            tg = A.get('tafsir_groups') or [[0], list(range(1, len(phrases)))]
        else:
            n = len(phrases); Lc = len(tafsir)
            k = 1 if (n == 1 or Lc < 170 or sp is None) else (2 if Lc < 520 else 3)
            k = min(k, n)
            while True:
                parts = split_tafsir(tafsir, k)
                k = len(parts)
                tg = [[] for _ in range(k)]
                for i, p in enumerate(phrases):  # place each phrase by its position inside the ayah
                    frac = ((p['w'][0] + p['w'][1]) / 2 - 1) / max(1, len(toks))
                    tg[min(k - 1, int(frac * k))].append(i)
                if all(tg) or k == 1:
                    break
                k -= 1
            if A.get('tafsir_groups'):
                tg = A['tafsir_groups']
        for gi, ids in enumerate(tg):
            gid = f'{ay}{"abcd"[gi]}'
            g = {'id': gid, 'tafsir': parts[gi], 'phrases': []}
            for k2 in ids:
                p = phrases[k2]; pid = f'{gid}{k2 + 1}'
                g['phrases'].append({'id': pid, 'text': p['text']})
                timeline.append({'id': pid, 'group': gid, 'start': p['s'], 'end': p['e']})
                review.append({'time': [p['s'], p['e']], 'ayah': ay, 'words': p['w'], 'text': p['text'],
                               'tafsir': parts[gi] if ids[0] == k2 else ''})
            groups.append(g)
        if r != 'hafs':
            review[-1]['note'] = f'التفسير للآية/الآيات {hafs_ayat} بعدّ حفص'
    ltr = tdir == 'ltr'
    tafsir_font = font_path('IBMPlexSans.ttf') if ltr else font_path('IBMPlexSansArabic-Medium.ttf')
    first, last = plan['ayat'][0]['ayah'], plan['ayat'][-1]['ayah']
    L = {'riwayah': r, 'riwayah_label': r_label, 'surah': S, 'surah_name': AY[first]['surah_name'],
         'ayah_from': first, 'ayah_to': last, 'reciter': plan.get('reciter', ''),
         'ayah_font': ayah_font, 'tafsir_font': tafsir_font, 'label_font': tafsir_font,
         'label_font_ar': font_path('IBMPlexSansArabic-Medium.ttf'), 'tafsir_var': 'Medium' if ltr else None,
         'tafsir_key': tk, 'tafsir_label': t_label, 'tafsir_lang': lang, 'tafsir_dir': tdir,
         'theme': resolve_theme(plan.get('theme', 'navy_gold'), plan.get('colors')), 'style': plan.get('style', {}),
         'brand': plan.get('brand', {}), 'groups': groups,
         'ayat_full': {a['ayah']: AY[a['ayah']]['text'] for a in plan['ayat']},
         'tafsir_full': {a['ayah']: ' '.join(TF.get(h, '') for h in (hmap.get(a['ayah']) or [a['ayah']])).strip() for a in plan['ayat']} if slug else {}}
    json.dump(L, open(os.path.join(O, 'layout.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    json.dump(timeline, open(os.path.join(O, 'timeline.json'), 'w'), indent=1)
    json.dump(review, open(os.path.join(O, 'review.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(f"{L['surah_name']} {first}-{last} | {r_label} | {t_label or 'بدون تفسير'} | theme {L['theme']['name']}")
    for g in groups:
        print(f"== {g['id']}  {g['tafsir'][:90]}{'…' if len(g['tafsir']) > 90 else ''}")
        for p, tl in zip(g['phrases'], [x for x in timeline if x['group'] == g['id']]):
            print(f"   {tl['start']:>7.2f}-{tl['end']:<7.2f} {p['text']}")


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
