# One command for one file or a whole folder (batch). Every step's files stay in OUT/<name>/ so a
# hand-edited plan.json is reused on the next run (delete it, or pass --replan, to rebuild it).
# usage: python3 run_all.py SRC [SRC ...] --out OUT [--riwayah hafs] [--tafsir muyassar] [--theme navy_gold]
#        [--modes reel,square] [--bg pattern] [--handle @name] [--reciter "name"] [--range 27:59-62]
#        [--plan-only] [--replan] [--fast] [--model auto|small|turbo|base] [--preview [SEC]] [--no-credit] [--no-verify]
# Defaults for handle/reciter/theme/riwayah/tafsir/modes/bg/model/credit/colors come from ~/quran-work/config.json (scripts/config.py).
# Explicit --theme/--tafsir/--handle/--reciter on an EXISTING plan update it (re-render in another look without re-transcribing).
import argparse, glob, json, os, subprocess, sys, time
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from common import ffmpeg_bin, load_config, probe

MEDIA = ('.mp4', '.mov', '.m4v', '.mkv', '.webm', '.avi', '.mp3', '.m4a', '.wav', '.aac', '.ogg', '.opus', '.flac')
MATCH_OK = 0.7  # --model auto: if fewer than this share of chunks were located in the mushaf, retry with the stronger model


def sh(*cmd, check=True):
    print('$', ' '.join(str(c) for c in cmd[:3]), '…', flush=True)
    return subprocess.run([str(c) for c in cmd], check=check)


def py(script, *args, check=True):
    return sh(sys.executable, os.path.join(HERE, script), *args, check=check)


def jload(p):
    return json.load(open(p, encoding='utf-8'))


def match_share(path):
    c = jload(path)['chunks']
    real = [x for x in c if x.get('text')]
    return sum(1 for x in real if x.get('loc')) / max(1, len(real))


def transcribe_and_match(B, a):
    chunks, matches = os.path.join(B, 'chunks.json'), os.path.join(B, 'matches.json')
    order = ['small', 'turbo'] if a.model == 'auto' else [a.model]
    for i, m in enumerate(order):
        if os.path.exists(chunks):
            os.remove(chunks)
        py('transcribe.py', os.path.join(B, 'audio16k.wav'), os.path.join(B, 'pauses.json'), chunks, '--model', m)
        py('match.py', chunks, matches, '--riwayah', a.riwayah)
        share = match_share(matches)
        print(f'نسبة المقاطع اللي انطبقت على المصحف: {share:.0%} (موديل {m})', flush=True)
        if share >= MATCH_OK or i == len(order) - 1:
            if share < MATCH_OK:
                print('⚠️  نسبة التطابق منخفضة: راجع matches.json، أو شغّل بـ --range إذا تعرف السورة والآيات', flush=True)
            return
        print('↻ التطابق ضعيف مع الموديل الخفيف، أعيد المحاولة بموديل turbo الأدق', flush=True)


def one(src, a, cfg):
    name = os.path.splitext(os.path.basename(src))[0][:60] or 'clip'
    B = os.path.join(a.out, name); os.makedirs(B, exist_ok=True)
    info = probe(src)
    print(f'\n=== {name}: {info["duration"]:.1f}s, {"video " + str(info["w"]) + "x" + str(info["h"]) if info["has_video"] else "audio only"}')
    wav = os.path.join(B, 'audio16k.wav')
    if not os.path.exists(wav):
        sh(ffmpeg_bin(), '-v', 'error', '-y', '-i', src, '-vn', '-ac', '1', '-ar', '16000', wav)
    py('pauses.py', wav, os.path.join(B, 'pauses.json'), str(a.pct))
    plan = os.path.join(B, 'plan.json')
    if os.path.exists(plan) and not a.replan and a.riwayah_cli and jload(plan).get('riwayah', 'hafs') != a.riwayah:
        print('الرواية تغيّرت عن الخطة الحالية → أعيد بناء الخطة'); a.replan = True
    if a.replan or not os.path.exists(plan):
        extra = [x for k in ('theme', 'tafsir', 'handle', 'reciter') if getattr(a, k) for x in ('--' + k, getattr(a, k))]
        if a.range:
            py('auto_plan.py', '--range', a.range, '--riwayah', a.riwayah, os.path.join(B, 'pauses.json'), plan, *extra)
        else:
            if a.replan or not os.path.exists(os.path.join(B, 'matches.json')):
                transcribe_and_match(B, a)
            py('auto_plan.py', os.path.join(B, 'matches.json'), os.path.join(B, 'pauses.json'), plan, *extra)
        if cfg.get('colors'):  # saved custom colours (brand identity) apply to every NEW plan
            P = jload(plan); P['colors'] = cfg['colors']
            json.dump(P, open(plan, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    else:  # existing plan + explicit options => re-render in another look, no re-transcribing
        P = jload(plan); changed = []
        for k in ('theme', 'tafsir', 'reciter'):
            v = getattr(a, k + '_cli')
            if v and P.get(k) != v:
                P[k] = v; changed.append(k)
                if k == 'theme':
                    P.pop('colors', None)  # a named theme replaces custom colours
        if a.handle_cli and (P.get('brand') or {}).get('handle') != a.handle_cli:
            P['brand'] = {**(P.get('brand') or {}), 'handle': a.handle_cli}; changed.append('handle')
        if changed:
            json.dump(P, open(plan, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
            print('حدّثت الخطة الموجودة:', ', '.join(changed))
    py('build_layout.py', plan, B)
    if a.plan_only:
        py('verify.py', B, '--src', src, '--stage', 'plan', check=False)
        return 0
    modes = a.modes.split(',')
    if a.preview:
        first = jload(os.path.join(B, 'timeline.json'))
        dur = max(4.0, min(a.preview, (first[0]['end'] + 1.5) if first else a.preview))
        o = os.path.join(B, f'preview_{modes[0]}.mp4')
        py('compose.py', '--build', B, '--src', src, '--mode', modes[0], '--out', o, '--bg', a.bg, '--fast', '--dur', f'{dur:.1f}')
        print(f'معاينة سريعة ({dur:.0f}ث): {o}\nإذا عجبتك شغّل نفس الأمر بدون --preview للتصيير الكامل.')
        return 0
    outs = []
    for m in modes:
        o = os.path.join(B, f'{name}_{m}.mp4')
        py('compose.py', '--build', B, '--src', src, '--mode', m, '--out', o, '--bg', a.bg, *(['--fast'] if a.fast else []))
        outs.append(o)
    from extras import cover, post_text, srt, review_pdf, qa_sheet
    L = jload(os.path.join(B, 'layout.json'))
    cover(L, src, os.path.join(B, 'cover.jpg'), a.bg)
    post_text(L, os.path.join(B, 'post.txt'), credit=a.credit)
    srt(L, B, os.path.join(B, 'captions.srt'))
    review_pdf(L, B, os.path.join(B, 'review.pdf'))
    qa_sheet(outs[0], B, os.path.join(B, 'qa.jpg'))
    print('outputs:', *outs, 'cover.jpg post.txt captions.srt review.pdf qa.jpg', sep='\n  ')
    if a.no_verify:
        return 0
    r = py('verify.py', B, '--src', src, check=False)
    return r.returncode


def main():
    cfg = load_config()
    ap = argparse.ArgumentParser()
    ap.add_argument('src', nargs='+'); ap.add_argument('--out', required=True)
    for k in ('riwayah', 'tafsir', 'theme', 'modes', 'bg', 'handle', 'reciter', 'model'):
        ap.add_argument('--' + k)
    ap.add_argument('--range')
    ap.add_argument('--plan-only', action='store_true'); ap.add_argument('--replan', action='store_true')
    ap.add_argument('--fast', action='store_true'); ap.add_argument('--no-credit', action='store_true')
    ap.add_argument('--no-verify', action='store_true')
    ap.add_argument('--preview', nargs='?', const=6.0, type=float, help='quick low-quality preview of the first N seconds (default 6)')
    ap.add_argument('--pct', type=float, default=12)
    a = ap.parse_args()
    # explicit CLI values (these may update an existing plan) vs config defaults (only used when building a new plan)
    a.riwayah_cli, a.theme_cli, a.tafsir_cli, a.handle_cli, a.reciter_cli = a.riwayah, a.theme, a.tafsir, a.handle, a.reciter
    a.riwayah = a.riwayah or cfg['riwayah']; a.theme = a.theme or cfg['theme']; a.tafsir = a.tafsir or cfg['tafsir']
    a.handle = a.handle or cfg['handle'] or None; a.reciter = a.reciter or cfg['reciter'] or None
    a.modes = a.modes or cfg['modes']; a.bg = a.bg or cfg['bg']; a.model = a.model or cfg['whisper_model']
    a.credit = cfg['credit'] and not a.no_credit
    files = []
    for s in a.src:
        files += sorted(f for f in glob.glob(os.path.join(s, '*')) if f.lower().endswith(MEDIA)) if os.path.isdir(s) else [s]
    t0 = time.time(); worst = 0
    for f in files:
        worst = max(worst, one(f, a, cfg) or 0)
    print(f'\nfinished {len(files)} file(s) in {time.time() - t0:.0f}s')
    if worst:
        print('⛔ الفحص الآلي لقى أخطاء — راجع verify_report.json وأصلحها قبل التسليم')
        sys.exit(2)


if __name__ == '__main__':
    main()
