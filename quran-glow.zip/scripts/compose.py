# Burn caption layers into a video (or build a video from an audio-only recitation).
# usage: python3 compose.py --build DIR --src FILE --mode original|square|reel|youtube --out OUT.mp4
#                           [--bg pattern|stars|bokeh|gradient|arch] [--fast] [--dur SEC]
import argparse, hashlib, json, os, subprocess, sys
import numpy as np
from PIL import Image
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import probe, ffmpeg_bin, hexrgb
from render import render_layers, render_brand
from background import make_video

CANVAS = {'square': (1080, 1080), 'reel': (1080, 1920), 'youtube': (1920, 1080)}


def even(x):
    return int(round(x / 2) * 2)


def geometry(mode, info):
    """-> W, H, video box (x, y, w, h) or None for audio-only, caption bottom offset, brand y."""
    sw, sh = info['w'], info['h']
    if not info['has_video']:
        W, H = CANVAS.get(mode, CANVAS['reel'])
        bot = {1920: 640, 1080: 270}[H] if W == 1080 else 250
        return W, H, None, bot, 110 if H == 1920 else 60
    if mode == 'original':
        W = 1920 if sw > sh else 1080
        H = even(W * sh / sw)
        return W, H, (0, 0, W, H), 54, 60
    W, H = CANVAS[mode]
    ar = sw / sh
    if mode == 'reel':
        fh = even(1080 / ar)
        if fh >= 1700:
            return W, H, (0, 0, 1080, 1920), 420, 150
        if fh >= 800:
            fy = (1920 - fh) // 2
            return W, H, (0, fy, 1080, fh), 1920 - (fy + fh) + 54, max(80, fy // 2)
        return W, H, (0, 400, 1080, fh), 430, 200
    if mode == 'square':
        if abs(ar - 1) < 0.05:
            return W, H, (0, 0, 1080, 1080), 54, 60
        if ar > 1:
            fh = even(1080 / ar); fy = (1080 - fh) // 2 - 80
            return W, H, (0, fy, 1080, fh), 40, 50
        fw = even(1080 * ar)
        return W, H, ((1080 - fw) // 2, 0, fw, 1080), 54, 50
    # youtube 16:9
    if ar >= 1.7:
        return W, H, (0, 0, 1920, 1080), 60, 50
    fw = even(1080 * ar)
    return W, H, ((1920 - fw) // 2, 0, fw, 1080), 60, 50


def shade_png(path, W, H, bot, theme, soft=False, top_band=0):
    yb = H - bot + 20
    st = [(0, 0), (yb - 530, 0), (yb - 300, .35), (yb - 170, .66), (min(yb, H), .86)]
    st += [(yb + 90, .6), (yb + 230, .38), (H, .42)] if H - yb > 120 else [(H, .88)]
    y = np.arange(H, dtype=np.float32)
    al = np.interp(y, [p[0] for p in st], [p[1] for p in st])
    if soft:
        al *= 0.55
    if top_band > 0:
        al = np.maximum(al, np.interp(y, [0, top_band * .7, top_band], [.30, .12, 0]))
    if theme.get('panel'):
        al *= 0.0  # paper panel theme draws its own card
    img = np.zeros((H, W, 4), np.uint8)
    img[..., :3] = hexrgb(theme['shade']) if not theme.get('panel') else (0, 0, 0)
    img[..., 3] = (al[:, None] * 255).astype(np.uint8)
    Image.fromarray(img, 'RGBA').save(path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--build', required=True); ap.add_argument('--src', required=True)
    ap.add_argument('--mode', default='reel', choices=['original', 'square', 'reel', 'youtube'])
    ap.add_argument('--out', required=True); ap.add_argument('--bg', default='pattern')
    ap.add_argument('--fast', action='store_true'); ap.add_argument('--dur', type=float)
    a = ap.parse_args()
    L = json.load(open(os.path.join(a.build, 'layout.json'), encoding='utf-8'))
    TL = json.load(open(os.path.join(a.build, 'timeline.json')))
    info = probe(a.src)
    DUR = min(info['duration'], a.dur or 1e9)
    W, H, box, bot, brand_y = geometry(a.mode, info)
    if not info['has_video']:  # audio-only: captions are the whole picture, so make them bigger
        st = L.setdefault('style', {})
        st.setdefault('fs', 80); st.setdefault('tfs', 29); st.setdefault('ayah_w', 940 if W < 1500 else 1400)
    lay = os.path.join(a.build, f'layers_{a.mode}')
    render_layers(L, lay, W, H, bot)
    brand = render_brand(L, lay, W, H, brand_y)
    shade_png(os.path.join(lay, 'shade.png'), W, H, bot, L['theme'], soft=not info['has_video'],
              top_band=(box[1] if box and box[1] > 100 else 0))
    fps = min(60.0, info['fps']) if info['has_video'] else 30.0
    ff = ffmpeg_bin()
    args = [ff, '-v', 'error', '-stats', '-y']
    if info['has_video']:
        args += ['-i', a.src]
        x, y, w, h = box
        up = ',unsharp=5:5:0.45' if info['w'] < w * 0.95 else ''
        if (x, y, w, h) == (0, 0, W, H):
            fc = [f'[0:v]scale={W}:{H}:force_original_aspect_ratio=increase:flags=lanczos,crop={W}:{H}{up},setsar=1,fps={fps}[b0]']
        else:
            bw, bh = W // 2, H // 2
            fc = ['[0:v]split=2[s1][s2]',
                  f'[s1]scale={bw}:{bh}:force_original_aspect_ratio=increase:flags=bilinear,crop={bw}:{bh},gblur=sigma=22:steps=3,'
                  f'eq=brightness=-0.06:saturation=1.1,scale={W}:{H}:flags=bicubic,setsar=1[bg]',
                  f'[s2]scale={w}:{h}:flags=lanczos{up},setsar=1[fg]', f'[bg][fg]overlay={x}:{y}:format=auto,fps={fps}[b0]']
        amap = '0:a?'
    else:
        # cache key includes theme colours + size + duration: a changed theme or a short preview must never reuse an old background
        key = hashlib.md5(json.dumps([L['theme'].get('bg'), a.bg, W, H, round(DUR, 1), a.fast]).encode()).hexdigest()[:8]
        bgv = os.path.join(a.build, f'bg_{a.mode}_{a.bg}_{key}.mp4')
        if not os.path.exists(bgv):
            print('rendering background…', flush=True)
            make_video(a.bg, L['theme'], W, H, DUR, bgv, fps=30, fast=a.fast)
        args += ['-i', bgv, '-i', a.src]
        fc = ['[0:v]setsar=1[b0]']
        amap = '1:a'
    grp = {}
    for t in TL:
        g = grp.setdefault(t['group'], [t['start'], t['end']]); g[0] = min(g[0], t['start']); g[1] = max(g[1], t['end'])
    layers = [(os.path.join(lay, 'shade.png'), 0, DUR, .8)]
    if brand:
        layers.append((brand, 0, DUR, .8))
    layers += [(os.path.join(lay, f't_{g}.png'), s, e, .45) for g, (s, e) in grp.items()]
    layers += [(os.path.join(lay, f"a_{t['id']}.png"), t['start'], t['end'], .45) for t in TL]
    layers = [(f, s, min(e, DUR), fi) for f, s, e, fi in layers if min(e, DUR) - s >= 0.2]
    n0 = 1 if info['has_video'] else 2
    for i, (f, s, e, fi) in enumerate(layers):
        d = e - s; fo = .35 if e < DUR - .1 else (.4 if i > 1 else 0)
        fi, fo = min(fi, d / 2), min(fo, d / 2)
        k = i + n0
        args += ['-loop', '1', '-framerate', str(int(round(fps))), '-t', f'{d:.3f}', '-i', f]
        ch = f'[{k}:v]format=rgba,fade=t=in:st=0:d={fi}:alpha=1' + (f',fade=t=out:st={d - fo:.3f}:d={fo}:alpha=1' if fo else '') + f',setpts=PTS+{s:.3f}/TB[l{i}]'
        fc += [ch, f'[b{i}][l{i}]overlay=0:0:eof_action=pass:format=auto[b{i + 1}]']
    fc[-1] = fc[-1].rsplit('[', 1)[0] + ',format=yuv420p[vout]'
    q = ['-preset', 'veryfast', '-crf', '19'] if a.fast else ['-preset', 'medium', '-crf', '17', '-profile:v', 'high']
    args += ['-filter_complex', ';'.join(fc), '-map', '[vout]', '-map', amap, '-c:v', 'libx264', *q, '-pix_fmt', 'yuv420p',
             '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-movflags', '+faststart', '-t', f'{DUR:.3f}', a.out]
    subprocess.run(args, check=True)
    print(f'done {a.out} {W}x{H} {DUR:.1f}s', flush=True)


if __name__ == '__main__':
    main()
