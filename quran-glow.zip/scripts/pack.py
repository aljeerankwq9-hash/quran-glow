# Rebuild ONLY the publishing pack (cover, post text, SRT, review PDF, QA sheet) from an existing OUT/<name> — no video re-render.
# usage: python3 pack.py OUT/<name> --src FILE [--bg pattern] [--no-credit] [--handle @x] [--reciter "name"] [--video OUT/<name>/<name>_reel.mp4]
import argparse, glob, json, os, subprocess, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from common import load_config
from extras import cover, post_text, qa_sheet, review_pdf, srt


def main():
    cfg = load_config()
    ap = argparse.ArgumentParser()
    ap.add_argument('build'); ap.add_argument('--src', required=True)
    ap.add_argument('--bg'); ap.add_argument('--no-credit', action='store_true'); ap.add_argument('--credit', action='store_true')
    ap.add_argument('--handle'); ap.add_argument('--reciter'); ap.add_argument('--video')
    a = ap.parse_args(); B = a.build
    LP = os.path.join(B, 'layout.json')
    L = json.load(open(LP, encoding='utf-8'))
    if a.reciter:
        L['reciter'] = a.reciter
    if a.handle:
        L['brand'] = {**(L.get('brand') or {}), 'handle': a.handle}
    if a.reciter or a.handle:  # keep plan.json in sync so the next full render agrees
        PP = os.path.join(B, 'plan.json'); P = json.load(open(PP, encoding='utf-8'))
        if a.reciter: P['reciter'] = a.reciter
        if a.handle: P['brand'] = {**(P.get('brand') or {}), 'handle': a.handle}
        json.dump(P, open(PP, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        st = os.stat(LP)  # reciter/handle never change the video frames: keep layout.json's timestamp so verify doesn't call the videos stale
        json.dump(L, open(LP, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        os.utime(LP, (st.st_atime, st.st_mtime))
    credit = (cfg['credit'] or a.credit) and not a.no_credit
    cover(L, a.src, os.path.join(B, 'cover.jpg'), a.bg or cfg['bg'])
    post_text(L, os.path.join(B, 'post.txt'), credit=credit)
    srt(L, B, os.path.join(B, 'captions.srt'))
    review_pdf(L, B, os.path.join(B, 'review.pdf'))
    vids = [a.video] if a.video else sorted(v for v in glob.glob(os.path.join(B, '*_*.mp4')) if not os.path.basename(v).startswith(('bg_', 'preview_')))
    if vids:
        qa_sheet(vids[0], B, os.path.join(B, 'qa.jpg'))
    print('pack rebuilt:', *(os.path.join(B, n) for n in ('cover.jpg', 'post.txt', 'post_full.txt', 'captions.srt', 'review.pdf') + (('qa.jpg',) if vids else ())), sep='\n  ')
    subprocess.run([sys.executable, os.path.join(HERE, 'verify.py'), B, '--src', a.src], check=False)


if __name__ == '__main__':
    main()
