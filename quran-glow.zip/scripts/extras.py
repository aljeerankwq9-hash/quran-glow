# Publishing pack: cover image, post caption, SRT subtitles, teacher review PDF, QA contact sheet.
import json, os, subprocess, sys
from PIL import Image, ImageDraw, ImageFilter, ImageOps
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import ffmpeg_bin, probe, hexrgb, arabic_digits, MARKS, TAFSIR_CREDIT, SOURCE_CREDIT
from render import Txt, render_block
from background import make_still


def grab(src, t, path):
    subprocess.run([ffmpeg_bin(), '-v', 'error', '-y', '-ss', f'{t:.2f}', '-i', src, '-frames:v', '1', path], check=True)
    return Image.open(path).convert('RGB')


def title_lines(L):
    a, b = arabic_digits(L['ayah_from']), arabic_digits(L['ayah_to'])
    rng = f'الآية {a}' if a == b else f'الآيات {a} – {b}'
    return 'سورة ' + L['surah_name'], rng


def cover(L, src, out, bg_style='pattern', W=1080, H=1920):
    th = L['theme']; info = probe(src)
    if info['has_video']:
        TL = json.load(open(os.path.join(os.path.dirname(out), 'timeline.json')))
        t = TL[min(1, len(TL) - 1)]['start'] + 1.5 if TL else info['duration'] * .3
        fr = grab(src, min(t, info['duration'] - .2), out + '.frame.png')
        bg = ImageOps.fit(fr, (W, H)).filter(ImageFilter.GaussianBlur(28))
        bg = Image.blend(bg, Image.new('RGB', (W, H), hexrgb(th['shade']) if not th.get('panel') else (0, 0, 0)), .45).convert('RGBA')
        card_w = 900; card = ImageOps.fit(fr, (card_w, int(card_w * min(1.0, fr.height / fr.width)))).convert('RGBA')
        m = Image.new('L', card.size, 0); ImageDraw.Draw(m).rounded_rectangle([0, 0, card.width - 1, card.height - 1], 36, fill=255)
        cy = 300
        bg.paste(card, ((W - card_w) // 2, cy), m)
        ImageDraw.Draw(bg).rounded_rectangle([(W - card_w) // 2 - 3, cy - 3, (W + card_w) // 2 + 2, cy + card.height + 2], 38,
                                            outline=hexrgb(th['accent']) + (220,), width=3)
        ty = cy + card.height + 70
    else:
        bg = make_still(bg_style, th, W, H).convert('RGBA'); ty = int(H * .40)
    t1, t2 = title_lines(L)
    T1 = Txt(L['ayah_font'], 112, True, 'ar', lh=1.5)
    blk, pad = render_block(T1, [t1], W - 120, th['ayah'], th['glow'], th.get('glow_strength', 1), shadow=.6, pad=90)
    bg.alpha_composite(blk, ((W - blk.width) // 2, ty - pad)); ty += T1.lh + 10
    for txt, size, col in [(t2, 44, th['accent']), (('بصوت ' + L['reciter']) if L.get('reciter') else '', 36, th['tafsir']),
                           (L['riwayah_label'] + (' · ' + L['tafsir_label'] if L.get('tafsir_label') else ''), 28, th['tafsir'])]:
        if not txt:
            continue
        T = Txt(L['label_font_ar'], size, True, 'ar', lh=1.5)
        b2, p2 = render_block(T, [txt], W - 120, col, shadow=.8, pad=30)
        bg.alpha_composite(b2, ((W - b2.width) // 2, ty - p2)); ty += T.lh + 6
    h = (L.get('brand') or {}).get('handle')
    if h:
        T = Txt(L['label_font_ar'], 30, not h.isascii(), 'ar' if not h.isascii() else 'en', lh=1.4)
        b3, p3 = render_block(T, [h], W - 120, th['accent'], shadow=.8, pad=20)
        bg.alpha_composite(b3, ((W - b3.width) // 2, max(ty + 40, 1560) - p3))
    bg.convert('RGB').save(out, quality=93)
    if os.path.exists(out + '.frame.png'):
        os.remove(out + '.frame.png')
    return out


def post_text(L, out, credit=True):
    a, b = arabic_digits(L['ayah_from']), arabic_digits(L['ayah_to'])
    name = MARKS.sub('', L['surah_name'])
    import re
    ayat = ' '.join(re.sub(chr(0xA0) + r'([٠-٩]+)', r' (\1)', v) for v in L['ayat_full'].values())
    head = f'﴿ {ayat} ﴾\n[سورة {name}: {a}{"" if a == b else "–" + b}] · {L["riwayah_label"]}'
    if L.get('reciter'):
        head += f'\nبصوت: {L["reciter"]}'
    tags = f'\n\n#القرآن_الكريم #تلاوة #تدبر #سورة_{name.replace(" ", "_")} #قرآن'
    tf = ''
    if L.get('tafsir_full'):
        tf = f'\n\n{L["tafsir_label"]}:\n' + '\n'.join(f'({arabic_digits(k)}) {v}' for k, v in L['tafsir_full'].items())
    cr = ''
    if credit:  # source credit (tafsir author + mushaf text); the reciter is already in the head
        cr = '\n\n— المصادر —\n' + SOURCE_CREDIT
        if L.get('tafsir_label'):
            cr += '\n' + TAFSIR_CREDIT.get(L.get('tafsir_key'), L['tafsir_label'])
    full = head + tf + cr + tags
    open(out.replace('.txt', '_full.txt'), 'w', encoding='utf-8').write(full)
    short = full if len(full) <= 2200 else head + ('\n\n' + L['tafsir_label'] + ' في الفيديو.' if tf else '') + cr + tags
    open(out, 'w', encoding='utf-8').write(short)
    return out


def srt(L, B, out):
    TL = json.load(open(os.path.join(B, 'timeline.json')))
    txt = {p['id']: p['text'] for g in L['groups'] for p in g['phrases']}
    ts = lambda s: f'{int(s // 3600):02d}:{int(s % 3600 // 60):02d}:{int(s % 60):02d},{int(round(s % 1 * 1000)) % 1000:03d}'
    with open(out, 'w', encoding='utf-8') as f:
        for i, t in enumerate(TL, 1):
            f.write(f"{i}\n{ts(t['start'])} --> {ts(t['end'])}\n{txt[t['id']]}\n\n")
    return out


def review_pdf(L, B, out):
    R = json.load(open(os.path.join(B, 'review.json'), encoding='utf-8'))
    th_ink = (30, 24, 16); W, H, M = 1240, 1754, 80
    A = Txt(L['ayah_font'], 40, True, 'ar', lh=1.75)
    T = Txt(L['tafsir_font'], 22, L['tafsir_dir'] == 'rtl', L['tafsir_lang'], var=L.get('tafsir_var'), lh=1.6)
    S = Txt(L['label_font_ar'], 22, True, 'ar', lh=1.5)
    TM = Txt(L['label_font_ar'], 20, False, 'en', lh=1.5)
    HD = Txt(L['label_font_ar'], 34, True, 'ar', lh=1.5)
    pages, page, y = [], None, 0

    def new_page():
        nonlocal page, y
        page = Image.new('RGB', (W, H), 'white'); d = ImageDraw.Draw(page)
        t1, t2 = title_lines(L)
        HD.draw(d, ['ورقة مراجعة قبل النشر — ' + t1 + ' · ' + t2], W / 2, M - 20, th_ink)
        S.draw(d, [L['riwayah_label'] + ' · ' + (L['tafsir_label'] or 'بدون تفسير')], W / 2, M + 34, (110, 90, 60))
        d.line([(M, M + 80), (W - M, M + 80)], fill=(200, 180, 140), width=2)
        pages.append(page); y = M + 100

    new_page()
    for r in R:
        al = A.wrap(r['text'], W - 2 * M - 160, 4)
        tl = T.wrap(r['tafsir'], W - 2 * M - 40, 12) if r.get('tafsir') else []
        need = len(al) * A.lh + len(tl) * T.lh + 50 + (S.lh if r.get('note') else 0)
        if y + need > H - M - 60:
            new_page()
        d = ImageDraw.Draw(page)
        TM.draw(d, [f"{r['time'][0]:.1f}–{r['time'][1]:.1f}s"], M + 70, y + 2, (140, 120, 90))
        S.draw(d, [f"آية {arabic_digits(r['ayah'])}"], M + 70, y + 30, (140, 120, 90))
        A.draw(d, al, W / 2 + 60, y, th_ink); y += len(al) * A.lh
        if tl:
            T.draw(d, tl, W / 2, y, (70, 60, 50)); y += len(tl) * T.lh
        if r.get('note'):
            S.draw(d, [r['note']], W / 2, y, (160, 60, 40)); y += S.lh
        d.line([(M + 40, y + 18), (W - M - 40, y + 18)], fill=(230, 222, 205), width=1); y += 40
    for i, p in enumerate(pages, 1):
        d = ImageDraw.Draw(p)
        S.draw(d, [f'نص الآيات من بيانات مجمع الملك فهد (KFGQPC) · التفسير من tafsir_api · صفحة {arabic_digits(i)}/{arabic_digits(len(pages))}'], W / 2, H - M + 10, (140, 130, 110))
        S.draw(d, ['تمت المراجعة: ____________   التاريخ: ________'], W / 2, H - M - 40, th_ink)
    pages[0].save(out, save_all=True, append_images=pages[1:], resolution=150)
    return out


def qa_sheet(video, B, out, cols=4):
    TL = json.load(open(os.path.join(B, 'timeline.json')))
    info = probe(video)
    thumbs = []
    for t in TL:
        m = min((t['start'] + t['end']) / 2, info['duration'] - .1)
        im = grab(video, m, out + '.tmp.png')
        im.thumbnail((360, 640)); thumbs.append(im)
    if os.path.exists(out + '.tmp.png'):
        os.remove(out + '.tmp.png')
    w, h = thumbs[0].size; rows = (len(thumbs) + cols - 1) // cols
    sheet = Image.new('RGB', (cols * (w + 8), rows * (h + 8)), 'white')
    for i, im in enumerate(thumbs):
        sheet.paste(im, ((i % cols) * (w + 8), (i // cols) * (h + 8)))
    sheet.save(out, quality=85)
    return out
