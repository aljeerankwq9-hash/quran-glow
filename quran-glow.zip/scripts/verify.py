# Automatic QA before delivery — does NOT replace looking at qa.jpg / full-size frames / review.pdf, it catches what eyes miss.
# usage: python3 verify.py OUT/<name> [--src FILE] [--stage plan|final]
#   plan  : plan.json / layout.json / timeline.json only (use right after --plan-only)
#   final : everything that exists (default): rendered layers, videos, publishing pack
# Exit code 1 if any ERROR. Writes OUT/<name>/verify_report.json
import argparse, glob, json, os, re, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import ffmpeg_bin, load_riwayah, load_tafsir, map_to_hafs, probe, tokens, TAFSIR

SIZES = {'reel': (1080, 1920), 'square': (1080, 1080), 'youtube': (1920, 1080)}
MIN_PHRASE_S, EDGE_PX = 1.0, 24
R = {'errors': [], 'warnings': [], 'info': [], 'checked': 0}


def err(m): R['errors'].append(m); print('  ❌', m)
def warn(m): R['warnings'].append(m); print('  ⚠️ ', m)
def info(m): R['info'].append(m); print('  ℹ️ ', m)
def passed(m): R['checked'] += 1; print('  ✅', m)


def digits(s):
    t = s.translate(str.maketrans('٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹', '01234567890123456789'))
    d = re.findall(r'\d+', t)
    return int(d[-1]) if d else None


def squash(s):  # tafsir comparison: ignore whitespace and the comma we are allowed to drop at split points
    return re.sub(r'[\s،,]', '', s)


def check_plan(B, src):
    print('\n[الخطة والنص]')
    plan = json.load(open(os.path.join(B, 'plan.json'), encoding='utf-8'))
    L = json.load(open(os.path.join(B, 'layout.json'), encoding='utf-8'))
    TLn = json.load(open(os.path.join(B, 'timeline.json')))
    r, S, tk = plan.get('riwayah', 'hafs'), plan['surah'], plan.get('tafsir', 'muyassar')
    AY = {x['ayah']: tokens(x['text']) for x in load_riwayah(r) if x['surah'] == S}
    if plan.get('approximate_timing'):
        warn('التوقيت تقريبي (وضع --range بدون تعرّف على الصوت): افحص كل مقطع بالعين')

    # 1) every phrase on screen == the mushaf words it claims (independent re-slice from the source data)
    shown = {p['id']: p['text'] for g in L['groups'] for p in g['phrases']}
    bad = 0
    for A in plan['ayat']:
        ay = A['ayah']
        if ay not in AY:
            err(f'الآية {ay} غير موجودة في سورة {S} برواية {r}'); continue
        for k, (f, t, s, e) in enumerate(A['phrases']):
            if not (1 <= f <= t <= len(AY[ay])):
                err(f'{S}:{ay} الكلمات {f}-{t} خارج المدى 1-{len(AY[ay])}'); bad += 1; continue
            pid = next((i for i, tx in shown.items() if re.fullmatch(rf'{ay}[a-d]{k + 1}', i)), None)
            exp = ' '.join(AY[ay][f - 1:t])
            if pid is None:
                err(f'الآية {ay} المقطع {k + 1} غير موجود في layout.json'); bad += 1
            elif shown[pid] != exp:
                err(f'نص {pid} لا يطابق المصدر:\n      المعروض: {shown[pid]}\n      المصدر : {exp}'); bad += 1
    if not bad:
        passed(f'نص كل المقاطع ({len(shown)}) يطابق نص المصحف كلمة بكلمة')

    # 2) word coverage / ayah order / ayah-end number
    prev_ay = None; cov_problems = 0
    for i, A in enumerate(plan['ayat']):
        ay, ph = A['ayah'], A['phrases']; n = len(AY.get(ay, []))
        if prev_ay is not None and ay != prev_ay + 1:
            warn(f'قفزة في الآيات: {prev_ay} ← {ay} (آيات ناقصة؟)'); cov_problems += 1
        prev_ay = ay
        for a, b in zip(ph, ph[1:]):
            if b[0] > a[1] + 1:
                warn(f'{S}:{ay} كلمات {a[1] + 1}-{b[0] - 1} ما تظهر بأي مقطع'); cov_problems += 1
            elif b[0] <= a[1]:
                info(f'{S}:{ay} تداخل كلمات بين مقطعين ({b[0]}-{a[1]}) — طبيعي إذا كرّر القارئ')
        first_w, last_w = ph[0][0], ph[-1][1]
        if first_w > 1 and i > 0:
            warn(f'{S}:{ay} أول مقطع يبدأ من الكلمة {first_w} وليس من أول الآية'); cov_problems += 1
        if last_w < n:
            warn(f'{S}:{ay} آخر مقطع ينتهي عند الكلمة {last_w} من {n} (آية ناقصة)'); cov_problems += 1
        elif n and digits(AY[ay][-1]) != ay:
            warn(f'{S}:{ay} ما لقيت رقم الآية ملصوق بآخر كلمة'); cov_problems += 1
    if not cov_problems:
        passed('تغطية الكلمات كاملة وترتيب الآيات سليم ورقم الآية لاصق بآخر كلمة')

    # 3) timeline
    tl = sorted(TLn, key=lambda x: x['start']); t_problems = 0
    for x in tl:
        d = x['end'] - x['start']
        if d <= 0:
            err(f"{x['id']}: النهاية قبل البداية"); t_problems += 1
        elif d < MIN_PHRASE_S:
            warn(f"{x['id']}: مدة العرض {d:.1f}ث قصيرة (أقل من {MIN_PHRASE_S}ث) — صعبة القراءة")
            t_problems += 1
    for a, b in zip(tl, tl[1:]):
        if b['start'] < a['end'] - 0.05:
            err(f"تداخل زمني بين {a['id']} و{b['id']} ({a['end'] - b['start']:.2f}ث): بيظهرون فوق بعض"); t_problems += 1
        elif b['start'] - a['end'] > 2.0:
            warn(f"فراغ {b['start'] - a['end']:.1f}ث بدون كابشن بين {a['id']} و{b['id']}"); t_problems += 1
    if src and os.path.exists(src):
        dur = probe(src)['duration']
        if tl and tl[-1]['end'] > dur + 0.3:
            err(f'آخر كابشن ينتهي {tl[-1]["end"]:.1f}ث وبعد نهاية المقطع ({dur:.1f}ث)'); t_problems += 1
    if not t_problems:
        passed(f'التوقيت: {len(tl)} مقطع بلا تداخل ولا فراغات طويلة ولا مدد قصيرة')

    # 4) tafsir verbatim
    if TAFSIR[tk][0]:
        TF = load_tafsir(tk, S)
        hmap = map_to_hafs(r, S, [A['ayah'] for A in plan['ayat']])
        tb = 0
        for A in plan['ayat']:
            ay = A['ayah']
            exp = ' '.join(TF.get(h, '') for h in (hmap.get(ay) or [ay])).strip()
            got = ' '.join(g['tafsir'] for g in L['groups'] if re.fullmatch(rf'{ay}[a-d]', g['id']))
            if squash(exp) != squash(got):
                err(f'تفسير الآية {ay} لا يطابق المصدر (فيه زيادة/نقص):\n      المصدر ({len(exp)} حرف) / المعروض ({len(got)} حرف)'); tb += 1
            elif not exp:
                warn(f'لا يوجد تفسير للآية {ay} في المصدر')
        if not tb:
            passed('التفسير المعروض يطابق نص المصدر حرفياً (يتقسّم فقط عند نهايات الجمل)')
    return plan, L, TLn


def newest(paths):
    return max((os.path.getmtime(p) for p in paths), default=0)


def check_layers(B, L):
    from PIL import Image
    lm = os.path.getmtime(os.path.join(B, 'layout.json'))
    dirs = []
    for d in sorted(glob.glob(os.path.join(B, 'layers_*'))):
        if newest(glob.glob(os.path.join(d, '*.png'))) < lm - 2:   # left over from an older run (other theme/text): not what we deliver
            warn(f'{os.path.basename(d)}: طبقات قديمة من تشغيل سابق — تخطيتها (أعد التصيير بهالمقاس عشان تنفحص)')
        else:
            dirs.append(d)
    if not dirs:
        info('ما فيه طبقات مصيّرة بعد (layers_*) — تخطيت فحص الشكل'); return
    panel = L['theme'].get('panel')
    print('\n[الشكل: الطبقات المصيّرة]')
    for d in dirs:
        mode = os.path.basename(d).replace('layers_', ''); bad = 0
        for g in L['groups']:
            tp = os.path.join(d, f"t_{g['id']}.png")
            if not os.path.exists(tp):
                err(f'[{mode}] ناقص {os.path.basename(tp)}'); bad += 1; continue
            T = Image.open(tp).getchannel('A').point(lambda v: 255 if v > 128 else 0)
            tb = T.getbbox()
            for p in g['phrases']:
                ap = os.path.join(d, f"a_{p['id']}.png")
                if not os.path.exists(ap):
                    err(f'[{mode}] ناقص {os.path.basename(ap)}'); bad += 1; continue
                Aim = Image.open(ap).getchannel('A').point(lambda v: 255 if v > 128 else 0)
                ab = Aim.getbbox(); W, H = Aim.size
                if ab is None:
                    err(f"[{mode}] {p['id']}: الطبقة فاضية (ما انرسم شي)"); bad += 1; continue
                if ab[0] < EDGE_PX or W - ab[2] < EDGE_PX or ab[1] < 0:
                    err(f"[{mode}] {p['id']}: الآية قريبة/مقصوصة من حافة الإطار (هوامش {ab[0]}/{W - ab[2]}px)"); bad += 1
                if tb and not panel and ab[3] > tb[1]:
                    err(f"[{mode}] {p['id']}: الآية تتداخل مع التفسير ({ab[3] - tb[1]}px) — صغّر الخط fs أو tfs"); bad += 1
                if ab[1] < H * 0.18:
                    warn(f"[{mode}] {p['id']}: الآية مرتفعة جداً بالإطار (تغطي أعلى الصورة) — غالباً آية طويلة، صغّر fs")
            if tb and (tb[0] < EDGE_PX or T.size[0] - tb[2] < EDGE_PX):
                err(f"[{mode}] تفسير {g['id']}: مقصوص من الجنب"); bad += 1
        if not bad:
            passed(f'[{mode}] كل الطبقات موجودة وداخل الإطار وبدون تداخل بين الآية والتفسير')


def has_audio(path):
    e = subprocess.run([ffmpeg_bin(), '-hide_banner', '-i', path], capture_output=True, text=True).stderr
    return 'Audio:' in e


def check_videos(B, src):
    vids = sorted(glob.glob(os.path.join(B, '*_*.mp4')))
    vids = [v for v in vids if not os.path.basename(v).startswith(('bg_', 'preview_'))]
    if not vids:
        return
    print('\n[الفيديوهات]')
    sinfo = probe(src) if src and os.path.exists(src) else None
    lm = os.path.getmtime(os.path.join(B, 'layout.json'))
    for v in vids:
        n = os.path.basename(v); mode = n.rsplit('_', 1)[1][:-4]; i = probe(v)
        if os.path.getmtime(v) < lm - 2:
            warn(f'{n}: فيديو قديم من تشغيل سابق (قبل آخر تعديل بالخطة) — لا تسلّمه، أعد تصييره'); continue
        if os.path.getsize(v) < 50_000 or not i['has_video']:
            err(f'{n}: الملف فاضي أو تالف'); continue
        ok = True
        if mode in SIZES and (i['w'], i['h']) != SIZES[mode]:
            err(f"{n}: المقاس {i['w']}x{i['h']} وليس {SIZES[mode][0]}x{SIZES[mode][1]}"); ok = False
        if sinfo and abs(i['duration'] - sinfo['duration']) > 0.4:
            err(f"{n}: المدة {i['duration']:.1f}ث بينما المقطع الأصلي {sinfo['duration']:.1f}ث"); ok = False
        if (sinfo is None or sinfo['duration'] > 0) and not has_audio(v):
            err(f'{n}: ما فيه مسار صوت!'); ok = False
        if ok:
            passed(f"{n}: {i['w']}x{i['h']} · {i['duration']:.1f}ث · الصوت موجود")


def check_pack(B, L, TLn):
    names = ['post.txt', 'captions.srt', 'review.pdf', 'cover.jpg', 'qa.jpg']
    if not any(os.path.exists(os.path.join(B, n)) for n in names):
        return
    print('\n[باقة النشر]')
    for n in names:
        p = os.path.join(B, n)
        if not os.path.exists(p) or os.path.getsize(p) == 0:
            err(f'ناقص: {n}')
    pt = os.path.join(B, 'post.txt')
    if os.path.exists(pt):
        n = len(open(pt, encoding='utf-8').read())
        (err if n > 2200 else passed)(f'post.txt = {n} حرف' + (' (يتعدى 2200 حد انستقرام)' if n > 2200 else ' (ضمن حد 2200)'))
    sp = os.path.join(B, 'captions.srt')
    if os.path.exists(sp):
        c = len(re.findall(r'^\d+$', open(sp, encoding='utf-8').read(), re.M))
        (err if c != len(TLn) else passed)(f'captions.srt = {c} مقطع' + ('' if c == len(TLn) else f' لكن الجدول الزمني {len(TLn)}'))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('build'); ap.add_argument('--src'); ap.add_argument('--stage', default='final', choices=['plan', 'final'])
    a = ap.parse_args(); B = a.build
    print(f'فحص آلي: {B}')
    plan, L, TLn = check_plan(B, a.src)
    if a.stage == 'final':
        check_layers(B, L); check_videos(B, a.src); check_pack(B, L, TLn)
    json.dump(R, open(os.path.join(B, 'verify_report.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(f"\nالنتيجة: {len(R['errors'])} خطأ · {len(R['warnings'])} تنبيه · {R['checked']} فحص ناجح")
    print('⛔ لا تسلّم قبل ما تصلح الأخطاء، وتنبّه المستخدم للتنبيهات.' if R['errors'] else '✔ الفحص الآلي سليم — لا يزال لازم تشوف qa.jpg ولقطة كاملة الدقة وورقة المراجعة بعينك.')
    sys.exit(1 if R['errors'] else 0)


if __name__ == '__main__':
    main()
