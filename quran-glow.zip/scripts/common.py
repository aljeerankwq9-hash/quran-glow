# Shared helpers: paths, riwayat, tafsir sources, themes, Arabic normalisation, ffmpeg.
import json, os, re, shutil, subprocess, difflib

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(HERE)
ASSETS = os.path.join(SKILL, 'assets')
WORK = os.environ.get('QURAN_WORK', os.path.join(os.path.expanduser('~'), 'quran-work'))
CACHE = os.path.join(WORK, 'cache')  # downloads go here (the plugin folder itself may be read-only)
CONFIG_PATH = os.path.join(WORK, 'config.json')  # per-user settings (handle, theme, ...) — survives plugin updates
try:
    VERSION = open(os.path.join(SKILL, 'VERSION'), encoding='utf-8').read().strip()
except OSError:
    VERSION = 'dev'

DEFAULT_CONFIG = {
    'handle': '', 'reciter': '', 'theme': 'navy_gold', 'riwayah': 'hafs', 'tafsir': 'muyassar',
    'modes': 'reel,square', 'bg': 'pattern', 'whisper_model': 'auto', 'credit': True, 'colors': None,
}


def load_config():
    """User settings = DEFAULT_CONFIG overridden by ~/quran-work/config.json (created by scripts/config.py)."""
    c = dict(DEFAULT_CONFIG)
    try:
        c.update({k: v for k, v in json.load(open(CONFIG_PATH, encoding='utf-8')).items() if k in DEFAULT_CONFIG})
    except (OSError, ValueError):
        pass
    return c


def save_config(c):
    os.makedirs(WORK, exist_ok=True)
    json.dump({k: c[k] for k in DEFAULT_CONFIG if k in c}, open(CONFIG_PATH, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)


def cached(sub, name):
    for base in (ASSETS, CACHE):  # a file shipped with the skill wins; otherwise it is downloaded to the cache
        p = os.path.join(base, sub, name)
        if os.path.exists(p) and os.path.getsize(p) > 0:
            return p
    return os.path.join(CACHE, sub, name)
RAW = 'https://raw.githubusercontent.com'
KFG = RAW + '/thetruetruth/quran-data-kfgqpc/main'
# KFGQPC text/font are NOT bundled (their terms do not clearly allow redistribution): they are downloaded on first use,
# trying several mirrors, or taken from assets/data/<riwayah>.json + assets/fonts/<riwayah>.ttf when the user uploads them.
KFG_MIRRORS = [RAW + '/thetruetruth/quran-data-kfgqpc/main',
               'https://cdn.jsdelivr.net/gh/thetruetruth/quran-data-kfgqpc@main',
               'https://cdn.statically.io/gh/thetruetruth/quran-data-kfgqpc/main']
TAFSIR_MIRRORS = [RAW + '/spa5k/tafsir_api/main', 'https://cdn.jsdelivr.net/gh/spa5k/tafsir_api@main']

# riwayah key -> (Arabic label, data path in KFGQPC repo, font path in repo)
RIWAYAT = {
    'hafs':   ('رواية حفص عن عاصم',   'hafs/data/hafsData_v18.json',     'hafs/font/hafs.18.ttf'),
    'shouba': ('رواية شعبة عن عاصم',  'shouba/data/ShoubaData08.json',   'shouba/font/shouba.8.ttf'),
    'warsh':  ('رواية ورش عن نافع',   'warsh/data/warshData_v10.json',   'warsh/font/warsh.10.ttf'),
    'qaloon': ('رواية قالون عن نافع', 'qaloon/data/QaloonData_v10.json', 'qaloon/font/qaloon.10.ttf'),
    'doori':  ('رواية الدوري عن أبي عمرو', 'doori/data/DooriData_v09.json', 'doori/font/doori.9.ttf'),
    'soosi':  ('رواية السوسي عن أبي عمرو', 'soosi/data/SoosiData09.json',  'soosi/font/soosi.9.ttf'),
    'bazzi':  ('رواية البزي عن ابن كثير', 'bazzi/data/BazziData_v07.json', 'bazzi/font/bazzi.7.ttf'),
    'qumbul': ('رواية قنبل عن ابن كثير', 'qumbul/data/QumbulData_v07.json', 'qumbul/font/qumbul.7.ttf'),
}

# tafsir key -> (spa5k slug, on-screen label, language, direction)
TAFSIR = {
    'muyassar':  ('ar-tafsir-muyassar',      'التفسير الميسر',        'ar', 'rtl'),
    'mukhtasar': ('ar-tafsir-al-mukhtasar',  'المختصر في التفسير',    'ar', 'rtl'),
    'saadi':     ('ar-tafsir-as-saadi',      'تفسير السعدي',          'ar', 'rtl'),
    'en':        ('en-tafsir-al-mukhtasar',  'Tafsir · Al-Mukhtasar', 'en', 'ltr'),
    'id':        ('indonesian-mokhtasar',    'Tafsir Al-Mukhtashar',  'id', 'ltr'),
    'tr':        ('turkish-mokhtasar',       'Muhtasar Tefsir',       'tr', 'ltr'),
    'fr':        ('french-mokhtasar',        'Tafsir Al-Mukhtasar',   'fr', 'ltr'),
    'ru':        ('russian-mokhtasar',       'Тафсир аль-Мухтасар',   'ru', 'ltr'),
    'fa':        ('persian-mokhtasar',       'تفسیر المختصر',         'fa', 'rtl'),
    'none':      (None, '', 'ar', 'rtl'),
}

TAFSIR_CREDIT = {  # who wrote it, for the post footer
    'muyassar': 'التفسير الميسر — مجمع الملك فهد لطباعة المصحف الشريف',
    'mukhtasar': 'المختصر في تفسير القرآن الكريم — مركز تفسير للدراسات القرآنية',
    'saadi': 'تفسير السعدي — الشيخ عبدالرحمن بن ناصر السعدي',
}
SOURCE_CREDIT = 'نص المصحف: مجمع الملك فهد لطباعة المصحف الشريف'

FONTS = {  # file name in assets/fonts -> download URL
    'IBMPlexSansArabic-Medium.ttf': RAW + '/google/fonts/main/ofl/ibmplexsansarabic/IBMPlexSansArabic-Medium.ttf',
    'IBMPlexSans.ttf': RAW + '/google/fonts/main/ofl/ibmplexsans/IBMPlexSans%5Bwdth,wght%5D.ttf',
}


def _valid(path, kind):
    """Reject HTML error pages / truncated files that a proxy or CDN may return instead of the real file."""
    try:
        if os.path.getsize(path) < 1000:
            return False
        head = open(path, 'rb').read(8)
        if kind == 'font':
            return head[:4] in (b'\x00\x01\x00\x00', b'true', b'OTTO', b'ttcf')
        if kind == 'json':
            return head.lstrip()[:1] in (b'[', b'{')
        return not head.lstrip().startswith(b'<')
    except OSError:
        return False


def fetch(url, dest, mirrors=None, kind=None):
    """Download once, cache in dest. `mirrors` = list of base URLs; url is the part after the base (or a full URL)."""
    if os.path.exists(dest) and os.path.getsize(dest) > 0:
        return dest
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    kind = kind or ('font' if dest.endswith('.ttf') else 'json' if dest.endswith('.json') else None)
    urls = [m.rstrip('/') + '/' + url.lstrip('/') for m in mirrors] if mirrors else [url]
    errs = []
    for u in urls:
        tmp = dest + '.part'
        r = subprocess.run(['curl', '-sSLf', '-m', '180', '--retry', '2', '-o', tmp, u], capture_output=True, text=True)
        if r.returncode == 0 and _valid(tmp, kind):
            os.replace(tmp, dest)
            return dest
        errs.append(f'{u} -> {(r.stderr or "bad content").strip()[:120]}')
        if os.path.exists(tmp):
            os.remove(tmp)
    name = os.path.basename(dest)
    raise SystemExit('تعذّر تنزيل ' + name + ' من كل المصادر:\n  ' + '\n  '.join(errs) +
                     '\nالحل: ارفع الملف يدوياً وحطه في  ' + os.path.join(ASSETS, os.path.basename(os.path.dirname(dest)), name) +
                     '\n(للنص والخط: مستودع thetruetruth/quran-data-kfgqpc أو موقع مجمع الملك فهد). وشغّل  python3 scripts/doctor.py  للتفاصيل.')


def riwayah_files(r):
    label, data, font = RIWAYAT[r]
    d = fetch(data, cached('data', r + '.json'), KFG_MIRRORS, 'json')
    f = fetch(font, cached('fonts', r + '.ttf'), KFG_MIRRORS, 'font')
    return d, f, label


def font_path(name):
    return fetch(FONTS[name], cached('fonts', name), None, 'font')


def load_riwayah(r):
    """-> list of dicts {surah, ayah, text, surah_name} in mushaf order."""
    d, _, _ = riwayah_files(r)
    out = []
    for x in json.load(open(d, encoding='utf-8')):
        s = int(x.get('sora', x.get('sura_no')))
        out.append({'surah': s, 'ayah': int(x['aya_no']), 'text': x['aya_text'].strip(),
                    'surah_name': (x.get('sora_name_ar') or x.get('sura_name_ar') or '').strip()})
    return out


def tokens(text):
    """Words of an ayah as stored (ayah number stays glued to the last word by a no-break space)."""
    return [t for t in text.split(' ') if t]


def load_tafsir(key, surah):
    slug = TAFSIR[key][0]
    if not slug:
        return {}
    p = fetch(f'tafsir/{slug}/{surah}.json', cached('tafsir', f'{slug}-{surah}.json'), TAFSIR_MIRRORS, 'json')
    d = json.load(open(p, encoding='utf-8'))
    d = d['ayahs'] if isinstance(d, dict) else d
    out = {}
    for x in d:
        if int(x.get('surah', surah)) != surah:
            continue
        t = re.sub(r'^\s*\{\d+\}\s*', '', x['text']).strip()  # Saadi prefixes "{n}"
        out[int(x['ayah'])] = re.sub(r'\s+', ' ', t)
    return out


def load_themes():
    return json.load(open(os.path.join(ASSETS, 'themes.json'), encoding='utf-8'))


def hexrgb(h):
    h = h.lstrip('#')
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def resolve_theme(name, overrides=None):
    th = load_themes()
    t = dict(th.get(name) or th['navy_gold'])
    t.update(overrides or {})
    return t


# ---------- Arabic normalisation (for matching speech to text, never for display) ----------
_R = lambda a, b: chr(a) + '-' + chr(b)
MARKS = re.compile('[' + _R(0x610, 0x61A) + _R(0x64B, 0x65F) + _R(0x6D6, 0x6DC) + _R(0x6DF, 0x6E4) + chr(0x6E7) + chr(0x6E8) + _R(0x6EA, 0x6ED) + chr(0x640) + ']')
LETTERS = re.compile('[^' + _R(0x621, 0x64A) + ' ]')


def norm(s):
    s = s.replace(chr(0x670), 'ا').replace(chr(0x6E5), '').replace(chr(0x6E6), '')
    s = MARKS.sub('', s)
    s = re.sub('[ٱأإآ]', 'ا', s).replace('ى', 'ي').replace('ة', 'ه').replace('ؤ', 'و').replace('ئ', 'ي').replace('ء', '')
    return LETTERS.sub('', s).replace('ا', '').strip()


WAQF = {chr(c) for c in range(0x6D6, 0x6DC)}  # waqf (pause) signs inside an ayah: ۖ ۗ ۘ ۙ ۚ ۛ


def map_to_hafs(r, surah, ayat):
    """For riwayah r, map each of `ayat` (its own numbering) to the Hafs ayah numbers it covers."""
    if r == 'hafs':
        return {a: [a] for a in ayat}
    def stream(rw):
        out = []
        for x in load_riwayah(rw):
            if x['surah'] != surah:
                continue
            for t in tokens(x['text']):
                n = norm(t)
                if n:
                    out.append((x['ayah'], n))
        return out
    A, H = stream(r), stream('hafs')
    sm = difflib.SequenceMatcher(None, [w for _, w in A], [w for _, w in H], autojunk=False)
    amap = {}
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag in ('equal', 'replace'):
            for k in range(i2 - i1):
                j = min(j1 + int(k * (j2 - j1) / max(1, i2 - i1)), j2 - 1)
                amap.setdefault(A[i1 + k][0], set()).add(H[j][0])
    return {a: sorted(amap.get(a, [])) for a in ayat}


# ---------- ffmpeg (system binary, or the one bundled with imageio-ffmpeg) ----------
def ffmpeg_bin():
    b = shutil.which('ffmpeg')
    if b:
        return b
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except ImportError:
        subprocess.run(['pip', 'install', '-q', '--break-system-packages', 'imageio-ffmpeg'], check=False)
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()


def probe(path):
    """Duration, video size/fps/rotation and whether a real video stream exists (ffprobe-free)."""
    p = subprocess.run([ffmpeg_bin(), '-hide_banner', '-i', path], capture_output=True, text=True)
    e = p.stderr
    m = re.search(r'Duration: (\d+):(\d+):([\d.]+)', e)
    dur = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3)) if m else 0.0
    info = {'duration': dur, 'has_video': False, 'w': 0, 'h': 0, 'fps': 30.0, 'rotation': 0}
    for line in e.splitlines():
        if 'Video:' in line and 'attached pic' not in line and '(mjpeg' not in line and 'png' not in line.split('Video:')[1][:12]:
            sz = re.search(r', (\d{2,5})x(\d{2,5})', line)
            if sz:
                info.update(has_video=True, w=int(sz.group(1)), h=int(sz.group(2)))
            fr = re.search(r'([\d.]+) fps', line)
            if fr:
                info['fps'] = float(fr.group(1))
            break
    rot = re.search(r'rotation of (-?[\d.]+)', e) or re.search(r'rotate\s*:\s*(-?\d+)', e)
    if rot:
        info['rotation'] = int(abs(float(rot.group(1)))) % 360
    if info['rotation'] in (90, 270):
        info['w'], info['h'] = info['h'], info['w']
    return info


def arabic_digits(n):
    return str(n).translate(str.maketrans('0123456789', '٠١٢٣٤٥٦٧٨٩'))
