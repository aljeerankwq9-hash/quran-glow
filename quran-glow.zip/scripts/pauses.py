# Breath pauses from the energy envelope. Usage: python3 pauses.py audio16k.wav pauses.json [percentile=12]
import sys, json, numpy as np, soundfile as sf
w, sr = sf.read(sys.argv[1], dtype='float32')
if w.ndim > 1: w = w.mean(1)
hop = int(0.05 * sr); n = len(w) // hop
db = 20 * np.log10(np.sqrt(np.mean(w[:n * hop].reshape(n, hop) ** 2, axis=1)) + 1e-9)
dbs = np.convolve(db, np.ones(3) / 3, mode='same')
pct = float(sys.argv[3]) if len(sys.argv) > 3 else 12
thr = np.percentile(db, pct); low = dbs <= thr  # <= so digitally silent gaps (edited audio, all equal to the floor) still count as pauses
runs, i = [], 0
while i < n:
    if low[i]:
        j = i
        while j < n and low[j]: j += 1
        if (j - i) * 0.05 >= 0.25: runs.append([round(i * .05, 2), round(j * .05, 2)])
        i = j
    else: i += 1
out = {'duration': round(len(w) / sr, 2), 'threshold_db': round(float(thr), 1), 'pauses': runs}
json.dump(out, open(sys.argv[2], 'w'), indent=1)
print('duration', out['duration'], 'thr', out['threshold_db'], 'pauses:', len(runs))
for r in runs: print(r)
