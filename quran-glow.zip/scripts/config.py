# User settings shared by all four skills (saved once in ~/quran-work/config.json).
# usage: python3 config.py show
#        python3 config.py set handle @name reciter "اسم القارئ" theme emerald riwayah warsh tafsir mukhtasar
#        python3 config.py set credit off
#        python3 config.py colors '{"ayah":"#FFFFFF","glow":"#C9A227","accent":"#C9A227","tafsir":"#FFFFFF","shade":"#0A1A2F","bg":["#0A1A2F","#16324F","#C9A227"],"glow_strength":1.0}'
#        python3 config.py reset
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import (CONFIG_PATH, DEFAULT_CONFIG, RIWAYAT, TAFSIR, load_config, load_themes, save_config)

BOOL = {'on': True, 'yes': True, 'true': True, '1': True, 'off': False, 'no': False, 'false': False, '0': False}


def check(k, v):
    if k == 'riwayah' and v not in RIWAYAT:
        raise SystemExit(f'riwayah must be one of {", ".join(RIWAYAT)}')
    if k == 'tafsir' and v not in TAFSIR:
        raise SystemExit(f'tafsir must be one of {", ".join(TAFSIR)}')
    if k == 'theme' and v not in load_themes():
        raise SystemExit(f'theme must be one of {", ".join(load_themes())}')
    if k == 'bg' and v not in ('pattern', 'stars', 'bokeh', 'gradient', 'arch'):
        raise SystemExit('bg must be pattern|stars|bokeh|gradient|arch')
    if k == 'modes' and not set(v.split(',')) <= {'reel', 'square', 'youtube', 'original'}:
        raise SystemExit('modes: any of reel,square,youtube,original (comma separated)')
    if k == 'whisper_model' and v not in ('auto', 'small', 'turbo', 'base'):
        raise SystemExit('whisper_model must be auto|small|turbo|base')
    if k == 'credit':
        if v.lower() not in BOOL:
            raise SystemExit('credit must be on|off')
        return BOOL[v.lower()]
    if k == 'handle' and v and not v.startswith('@'):
        return '@' + v
    return v


def main(a):
    c = load_config()
    if not a or a[0] == 'show':
        print(json.dumps(c, ensure_ascii=False, indent=1)); print('file:', CONFIG_PATH, '(exists)' if os.path.exists(CONFIG_PATH) else '(not created yet — defaults)')
    elif a[0] == 'set':
        kv = a[1:]
        if len(kv) % 2 or not kv:
            raise SystemExit('usage: config.py set key value [key value ...]')
        for k, v in zip(kv[::2], kv[1::2]):
            if k not in DEFAULT_CONFIG or k == 'colors':
                raise SystemExit(f'unknown key {k}; keys: {", ".join(k for k in DEFAULT_CONFIG if k != "colors")} (colors: use the colors command)')
            c[k] = check(k, v)
        save_config(c); print('saved'); print(json.dumps(c, ensure_ascii=False, indent=1))
    elif a[0] == 'colors':
        col = json.loads(a[1]) if len(a) > 1 and a[1] != 'none' else None
        if col:
            need = {'ayah', 'glow', 'accent', 'tafsir', 'shade', 'bg'}
            if not need <= set(col) or len(col['bg']) != 3:
                raise SystemExit('colors needs: ayah, glow, accent, tafsir, shade, bg[3] (+ optional glow_strength 0-1.5)')
        c['colors'] = col; save_config(c); print('saved colors:', col)
    elif a[0] == 'reset':
        if os.path.exists(CONFIG_PATH):
            os.remove(CONFIG_PATH)
        print('reset to defaults')
    else:
        raise SystemExit(__doc__)


if __name__ == '__main__':
    main(sys.argv[1:])
