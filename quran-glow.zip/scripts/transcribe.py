# Whisper-transcribe each breath-delimited chunk (sherpa-onnx, CPU).
# usage: python3 transcribe.py audio16k.wav pauses.json chunks.json [--model turbo|small|base]
import argparse, json, os, sys, subprocess, numpy as np, soundfile as sf
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import WORK

GH = 'https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models'


NOTE = {'turbo': 'الأدق لكنه الأثقل (حوالي 1GB)', 'small': 'متوازن: أخف بكثير من turbo وكافي لأغلب التلاوات', 'base': 'الأخف والأقل دقة'}
ORDER = {'turbo': ('turbo', 'small', 'base'), 'small': ('small', 'turbo', 'base'), 'base': ('base', 'small', 'turbo')}


def get_model(name):
    d = os.path.join(WORK, 'models', f'sherpa-onnx-whisper-{name}')
    if not os.path.isdir(d):
        print(f'⬇️  تنزيل موديل التعرّف على الصوت «{name}» — {NOTE.get(name, "")} — مرة وحدة بس وينحفظ للمرات الجاية', flush=True)
        os.makedirs(os.path.dirname(d), exist_ok=True)
        tb = d + '.tar.bz2'
        subprocess.run(['curl', '-sSLf', '--retry', '2', '-o', tb, f'{GH}/sherpa-onnx-whisper-{name}.tar.bz2'], check=True)
        subprocess.run(['tar', 'xjf', tb, '-C', os.path.dirname(d)], check=True)
        os.remove(tb)
    return d


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('wav'); ap.add_argument('pauses'); ap.add_argument('out')
    ap.add_argument('--model', default='small'); ap.add_argument('--threads', type=int, default=os.cpu_count() or 2)
    a = ap.parse_args()
    import sherpa_onnx
    rec = None
    for name in ORDER.get(a.model, ORDER['small']):
        try:
            d = get_model(name)
            rec = sherpa_onnx.OfflineRecognizer.from_whisper(
                encoder=f'{d}/{name}-encoder.int8.onnx', decoder=f'{d}/{name}-decoder.int8.onnx',
                tokens=f'{d}/{name}-tokens.txt', language='ar', task='transcribe', num_threads=a.threads)
            print('model:', name, flush=True); break
        except Exception as e:
            print(f'model {name} unavailable: {e}', flush=True)
    if rec is None:
        raise SystemExit('no speech model could be loaded — use auto_plan.py --range instead')
    w, sr = sf.read(a.wav, dtype='float32')
    if w.ndim > 1:
        w = w.mean(1)
    P = json.load(open(a.pauses)); dur = P['duration']
    segs, t = [], 0.0
    for x, y in P['pauses']:
        if x - t > 0.6:
            segs.append([t, x])
        t = y
    if dur - t > 0.6:
        segs.append([t, dur])

    def split_long(x0, x1):  # > 22 s: cut at the quietest 0.3 s in the middle part
        if x1 - x0 <= 22:
            return [[x0, x1]]
        x = w[int(x0 * sr):int(x1 * sr)]; win = int(0.3 * sr); lo, hi = int(len(x) * .3), int(len(x) * .7)
        e = [np.mean(x[k:k + win] ** 2) for k in range(lo, hi - win, win // 3)]
        c = x0 + (lo + int(np.argmin(e)) * (win // 3) + win / 2) / sr
        return split_long(x0, c) + split_long(c, x1)
    segs = [s for x0, x1 in segs for s in split_long(x0, x1)]
    out = []
    for x0, x1 in segs:
        s = rec.create_stream(); s.accept_waveform(sr, w[int(x0 * sr):int(x1 * sr)]); rec.decode_stream(s)
        d = {'start': round(x0, 2), 'end': round(x1, 2), 'text': s.result.text.strip()}
        out.append(d); print(d, flush=True)
    json.dump(out, open(a.out, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)


if __name__ == '__main__':
    main()
