# Health check: tells the user (in Arabic) exactly what is missing and what to do. usage: python3 doctor.py [--no-net]
import os, shutil, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import (ASSETS, CACHE, CONFIG_PATH, KFG_MIRRORS, TAFSIR_MIRRORS, VERSION, WORK, cached, ffmpeg_bin, load_config)

ok = lambda m: print('  ✅', m)
bad = lambda m: print('  ❌', m)
warn = lambda m: print('  ⚠️ ', m)
problems = 0


def reach(url):
    """Ask for the first byte of a REAL file (base URLs of a repo answer 404 even when the mirror works)."""
    r = subprocess.run(['curl', '-sS', '-m', '15', '-r', '0-0', '-o', '/dev/null', '-w', '%{http_code}', url], capture_output=True, text=True)
    return r.stdout.strip() in ('200', '206', '301', '302')


def main(net=True):
    global problems
    print(f'بلقن الكابشن القرآني — النسخة {VERSION}')
    print('\n[الأدوات]')
    try:
        from PIL import features
        if features.check('raqm'):
            ok('Pillow مع raqm (تشكيل الحروف العربية)')
        else:
            bad('Pillow بدون raqm → شغّل: pip install -U pillow'); problems += 1
    except ImportError:
        bad('Pillow غير مثبّت → bash scripts/setup.sh'); problems += 1
    try:
        ok('ffmpeg: ' + ffmpeg_bin())
    except Exception as e:
        bad(f'ffmpeg غير متوفر ({e}) → bash scripts/setup.sh'); problems += 1
    for mod in ('numpy', 'soundfile', 'sherpa_onnx'):
        try:
            __import__(mod); ok(mod)
        except ImportError:
            bad(f'{mod} غير مثبّت → bash scripts/setup.sh'); problems += 1
    free = shutil.disk_usage(os.path.expanduser('~')).free / 2**30
    (ok if free > 3 else warn)(f'مساحة فاضية {free:.1f}GB (التصيير والموديلات تحتاج 3GB على الأقل)')

    print('\n[الملفات]')
    for n in ('IBMPlexSansArabic-Medium.ttf', 'IBMPlexSans.ttf'):
        (ok if os.path.exists(os.path.join(ASSETS, 'fonts', n)) else bad)(f'خط {n} داخل البلقن')
    r = load_config()['riwayah']
    have_data = os.path.exists(cached('data', r + '.json')) and os.path.getsize(cached('data', r + '.json')) > 0
    have_font = os.path.exists(cached('fonts', r + '.ttf')) and os.path.getsize(cached('fonts', r + '.ttf')) > 0
    (ok if have_data else warn)(f'نص المصحف ({r}): ' + ('موجود' if have_data else 'ينزّل أول مرة'))
    (ok if have_font else warn)(f'خط المصحف ({r}): ' + ('موجود' if have_font else 'ينزّل أول مرة'))
    models = os.path.join(WORK, 'models')
    got = [d.replace('sherpa-onnx-whisper-', '') for d in (os.listdir(models) if os.path.isdir(models) else [])]
    ok('موديلات Whisper الموجودة: ' + ', '.join(got)) if got else warn('ما فيه موديل Whisper محمّل بعد (ينزّل أول تفريغ؛ small أخف من turbo)')
    print('  ملف الإعدادات:', CONFIG_PATH, '' if os.path.exists(CONFIG_PATH) else '(غير موجود — الإعدادات الافتراضية)')

    if net:
        print('\n[الاتصال]')
        groups = [('نص وخط المصحف', [m + '/hafs/data/hafsData_v18.json' for m in KFG_MIRRORS], not (have_data and have_font)),
                  ('التفسير', [m + '/tafsir/ar-tafsir-muyassar/1.json' for m in TAFSIR_MIRRORS], True),
                  ('موديل Whisper', ['https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-whisper-small.tar.bz2'], not got)]
        for label, urls, needed in groups:
            res = [(u, reach(u)) for u in urls]
            for u, good in res:
                (ok if good else warn)(('يوصل: ' if good else 'لا يوصل: ') + u)
            if not any(g for _, g in res):
                if needed:
                    bad(f'{label}: كل المصادر محجوبة. ' + ('ارفع assets/data/hafs.json و assets/fonts/hafs.ttf يدوياً (من مستودع thetruetruth/quran-data-kfgqpc).' if 'المصحف' in label else 'اطلب من المستخدم يرفع الملفات المطلوبة أو غيّر إعدادات الشبكة في Claude (Admin settings → Capabilities).'))
                    problems += 1
                else:
                    warn(f'{label}: المصادر محجوبة، لكن عندك نسخة محفوظة فما راح تحتاجها')
    print('\n' + ('كل شي تمام ✅' if not problems else f'فيه {problems} مشكلة تحتاج حل ❌'))
    return problems


if __name__ == '__main__':
    sys.exit(1 if main('--no-net' not in sys.argv) else 0)
