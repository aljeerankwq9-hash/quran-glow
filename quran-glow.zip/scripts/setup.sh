#!/usr/bin/env bash
# One-time setup per session (safe to re-run). Usage: bash scripts/setup.sh [--prefetch riwayah ...]
#   --prefetch hafs warsh   : also download the text+font of those riwayat now (otherwise on first use)
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
PIP="pip install -q --break-system-packages"
$PIP -U "pillow>=10.1" numpy soundfile sherpa-onnx 2>/dev/null || pip install -q -U "pillow>=10.1" numpy soundfile sherpa-onnx
command -v ffmpeg >/dev/null || $PIP imageio-ffmpeg 2>/dev/null || pip install -q imageio-ffmpeg
PREFETCH=""
if [ "$1" = "--prefetch" ]; then shift; PREFETCH="$*"; fi
python3 -c "
import sys; sys.path.insert(0, '$HERE')
from PIL import features
assert features.check('raqm'), 'Pillow has no raqm (Arabic shaping): run  pip install -U pillow'
from common import riwayah_files, font_path, ffmpeg_bin
riwayah_files('hafs'); font_path('IBMPlexSansArabic-Medium.ttf'); font_path('IBMPlexSans.ttf')
for r in '$PREFETCH'.split():
    riwayah_files(r)
print('ffmpeg:', ffmpeg_bin())
print('setup ok')
" || { echo; echo "الإعداد وقف. شغّل  python3 $HERE/doctor.py  عشان يعطيك السبب والحل."; exit 1; }
