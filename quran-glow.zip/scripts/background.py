# Abstract animated backgrounds for audio-only recitations.
# Only abstract shapes: geometric patterns, stars, soft light, gradients, arch outline.
# NEVER draw living beings or any depiction/illustration of what the ayat describe.
import math, os, random, subprocess, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import hexrgb, ffmpeg_bin

STYLES = ('pattern', 'stars', 'bokeh', 'gradient', 'arch')


def radial(W, H, inner, outer, cx=.5, cy=.42, r=.85):
    y, x = np.mgrid[0:H, 0:W].astype(np.float32)
    d = np.sqrt(((x - W * cx) / (W * r)) ** 2 + ((y - H * cy) / (H * r)) ** 2).clip(0, 1)[..., None]
    a, b = np.array(hexrgb(inner), np.float32), np.array(hexrgb(outer), np.float32)
    return Image.fromarray((a * (1 - d) + b * d).astype(np.uint8), 'RGB')


def star_lattice(W, H, color, alpha, tile=170, width=2):
    """Classic 8-point star (khatam) lattice drawn as outlines."""
    img = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    c = hexrgb(color) + (alpha,)
    r = tile * 0.42
    for j in range(-1, H // tile + 2):
        for i in range(-1, W // tile + 2):
            cx, cy = i * tile + (tile / 2 if j % 2 else 0), j * tile * 0.87
            for rot in (0, 45):
                pts = [(cx + r * math.cos(math.radians(rot + 45 + 90 * k)), cy + r * math.sin(math.radians(rot + 45 + 90 * k))) for k in range(4)]
                d.polygon(pts, outline=c, width=width)
            d.ellipse([cx - r * .28, cy - r * .28, cx + r * .28, cy + r * .28], outline=c, width=width)
    return img.filter(ImageFilter.GaussianBlur(0.6))


def make_still(style, theme, W, H, seed=7):
    c0, c1, acc = theme['bg']
    light = theme.get('panel')  # light (paper) themes
    rnd = random.Random(seed)
    base = radial(W, H, c1, c0).convert('RGBA')
    if style == 'pattern':
        base = Image.alpha_composite(base, star_lattice(W, H, acc, 70 if light else 46))
    elif style == 'arch':
        base = Image.alpha_composite(base, star_lattice(W, H, acc, 26 if not light else 40, tile=220, width=1))
        arch = Image.new('RGBA', (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(arch)
        aw, top, bot = W * .78, H * .12, H * .93
        x0, x1 = (W - aw) / 2, (W + aw) / 2
        pts = [(x0, bot), (x0, top + aw * .55)]
        for k in range(41):  # pointed (ogee-like) arch outline
            t = k / 40
            x = x0 + aw * t
            y = top + aw * .55 - math.sin(math.pi * t) ** 0.7 * aw * .55
            pts.append((x, y))
        pts += [(x1, top + aw * .55), (x1, bot)]
        for wdt, al in ((14, 40), (5, 120), (2, 230)):
            d.line(pts, fill=hexrgb(acc) + (al,), width=wdt, joint='curve')
        base = Image.alpha_composite(base, arch.filter(ImageFilter.GaussianBlur(1.2)))
    elif style == 'stars':
        y = np.linspace(0, 1, H)[:, None, None]
        g = (np.array(hexrgb(c0)) * (1 - y) + np.array(hexrgb(c1)) * y).astype(np.uint8)
        base = Image.fromarray(np.repeat(g, W, axis=1), 'RGB').convert('RGBA')
        st = Image.new('RGBA', (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(st)
        for _ in range(int(W * H / 2600)):
            x, yy, s = rnd.random() * W, rnd.random() * H, rnd.choice([0.8, 1, 1, 1.3, 1.8, 2.6])
            a = rnd.randint(90, 255)
            d.ellipse([x - s, yy - s, x + s, yy + s], fill=(255, 250, 235, a))
        glow = st.filter(ImageFilter.GaussianBlur(3))
        base = Image.alpha_composite(Image.alpha_composite(base, glow), st)
    elif style == 'bokeh':
        lay = Image.new('RGBA', (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
        for _ in range(34):
            x, yy, s = rnd.random() * W, rnd.random() * H, rnd.uniform(W * .03, W * .11)
            col = hexrgb(acc) if rnd.random() < .6 else tuple(min(255, v + 60) for v in hexrgb(c1))
            d.ellipse([x - s, yy - s, x + s, yy + s], fill=col + (rnd.randint(25, 70),))
        base = Image.alpha_composite(base, lay.filter(ImageFilter.GaussianBlur(W * .012)))
    # gentle vignette
    y, x = np.mgrid[0:H, 0:W].astype(np.float32)
    v = (np.sqrt(((x - W / 2) / (W * .75)) ** 2 + ((y - H / 2) / (H * .75)) ** 2).clip(0, 1) ** 2 * (60 if light else 140)).astype(np.uint8)
    vig = Image.new('RGBA', (W, H), (0, 0, 0, 0)); vig.putalpha(Image.fromarray(v, 'L'))
    return Image.alpha_composite(base, vig).convert('RGB')


def make_video(style, theme, W, H, dur, out, fps=30, fast=False):
    """Slow, smooth drift (sub-pixel) + breathing light, rendered frame by frame to H.264."""
    M = 1.10
    big = make_still(style, theme, int(W * M), int(H * M))
    light = Image.new('L', big.size, 0)
    ImageDraw.Draw(light).ellipse([big.width * .15, big.height * .18, big.width * .85, big.height * .62], fill=255)
    light = light.filter(ImageFilter.GaussianBlur(big.width * .12))
    lc = Image.new('RGB', big.size, hexrgb(theme['bg'][2]))
    n = int(dur * fps) + 1
    cmd = [ffmpeg_bin(), '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{W}x{H}', '-r', str(fps), '-i', '-',
           '-c:v', 'libx264', '-preset', 'veryfast' if fast else 'medium', '-crf', '16', '-pix_fmt', 'yuv420p', out]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    ax, ay = (big.width - W) / 2, (big.height - H) / 2
    levels = 12  # breathing light: pre-blend a few intensities once, pick the nearest per frame (fast)
    lits = [Image.composite(lc, big, light.point(lambda v, a=0.04 + 0.12 * q / (levels - 1): int(v * a))) for q in range(levels)]
    for k in range(n):
        t = k / fps
        lit = lits[int(round((0.5 + 0.5 * math.sin(t * 2 * math.pi / 9)) * (levels - 1)))]
        dx = ax + ax * 0.85 * math.sin(t * 2 * math.pi / 41)
        dy = ay + ay * 0.85 * math.sin(t * 2 * math.pi / 53 + 1.1)
        fr = lit.transform((W, H), Image.AFFINE, (1, 0, dx, 0, 1, dy), resample=Image.BILINEAR)
        p.stdin.write(fr.tobytes())
    p.stdin.close(); p.wait()
    return out


if __name__ == '__main__':  # preview: python3 background.py style theme_name out.png [W H]
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from common import resolve_theme
    W, H = (int(sys.argv[4]), int(sys.argv[5])) if len(sys.argv) > 5 else (1080, 1920)
    make_still(sys.argv[1], resolve_theme(sys.argv[2]), W, H).save(sys.argv[3])
